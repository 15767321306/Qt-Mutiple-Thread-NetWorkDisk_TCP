#include "filethread.h"
#include <QDebug>

FileThread::FileThread(MySocket* socket, QObject *parent)
    : QObject(parent), mySocket(socket)
{
    downFile = new QFile(this);
}

void FileThread::handleDownload(const QString &filePath, const QString &fileName,const QString &Tip)
{
    QString strFilePath = QString("%1/%2").arg(filePath).arg(fileName); // 文件路径
    qDebug() << "下载文件路径：" << strFilePath;

    downFile->setFileName(strFilePath);

    // 检查文件是否存在
    if (!downFile->exists()) {
        qDebug() << "文件不存在：" << strFilePath;
        PDU* respdu = mkPDU(0);
        respdu->uiMsgType = ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND;
        memcpy(respdu->caData, DOWNLOAD_FILE_FAIL, 64);
        if(Tip == DOWNLOAD_FILE_SHARE)
        {
            memcpy(respdu->caData+64,DOWNLOAD_FILE_SHARE,64);
        }
        emit downloadRespond(respdu);
        return;
    } else {
        qDebug() << "文件存在：" << strFilePath;
    }

    qint64 fileSize = downFile->size();
    qDebug() << "fileSize:" << fileSize;

    PDU* respdu = nullptr;
    if(downFile->open(QIODevice::ReadOnly))
    {
        qDebug() << "文件成功打开";
        respdu = mkPDU(64 + sizeof(qint64) + 5);
        respdu->uiMsgType = ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND;
        memcpy(respdu->caData, DOWNLOAD_FILE_START, 64);
        if(Tip == DOWNLOAD_FILE_SHARE)
        {
            memcpy(respdu->caData+64,DOWNLOAD_FILE_SHARE,64);
        }
        sprintf(respdu->caMsg, "%s %lld", fileName.toUtf8().data(), fileSize);

        emit downloadRespond(respdu);

        //延时一秒

        // 延时一秒后发送文件数据
        QTimer::singleShot(1000, this, SLOT(sendFileData()));
    }
    else
    {
        qDebug() << "无法打开文件：" << downFile->errorString();
        respdu = mkPDU(0);
        respdu->uiMsgType = ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND;
        memcpy(respdu->caData, DOWNLOAD_FILE_FAIL, 64);
        if(Tip == DOWNLOAD_FILE_SHARE)
        {
            memcpy(respdu->caData+64,DOWNLOAD_FILE_SHARE,64);
        }
        emit downloadRespond(respdu);
    }
}

void FileThread::startReceivingFile(TransFile* transfile, QByteArray data) {
    PDU* res = nullptr;
    if (transfile->bTransform) {
        qDebug() << "接收数据大小:" << data.size();

        // 将 QByteArray 的数据写入文件
        if (transfile->file.write(data) == -1) {
            qDebug() << "写入文件失败，错误:" << transfile->file.errorString();
            return; // 写入失败，直接返回
        }

        // 更新已接收大小
        transfile->iReceivedSize += data.size();
        qDebug() << "已接收大小:" << transfile->iReceivedSize;

        // 调试信息
        qDebug() << "预期接收总大小:" << transfile->iTotalSize;

        if (transfile->iReceivedSize == transfile->iTotalSize) {
            transfile->file.close();
            transfile->bTransform = false;
            qDebug() << "文件接收完毕";
            res = mkPDU(0);
            res->uiMsgType = ENUM_MSG_TYPE_UPLOAD_FINISHED;
            memcpy(res->caData, UPLOAD_FILE_OK, 64);
        } else if (transfile->iReceivedSize > transfile->iTotalSize) {
            qDebug() << "接收大小超过预期大小";
            qDebug() << "接收大小:" << transfile->iReceivedSize;
            qDebug() << "预期大小:" << transfile->iTotalSize;
            transfile->file.close();
            transfile->bTransform = false;
            qDebug() << "文件接收失败";
            res = mkPDU(0);
            res->uiMsgType = ENUM_MSG_TYPE_UPLOAD_FINISHED;
            memcpy(res->caData, UPLOAD_FILE_FAIL, 64);
        }
    }

    if (res != nullptr) {
        emit fileReceived(res); // 发射信号，通知文件接收状态
    }
}

void FileThread::sendFileData()
{
    if (!downFile->isOpen()) {
        qDebug() << "文件未打开，无法发送数据";
        return;
    }

    // 读取文件数据
    while(true)
    {
        QByteArray data = downFile->read(4096);
        if (data.isEmpty()) {
            qDebug() << "文件发送完毕";
            downFile->close();
            break;
        }

        qDebug() << "发送数据大小:" << data.size();
        // 创建 PDU
        PDU* pdu = mkPDU(data.size());
        //pdu->uiMsgType = ENUM_MSG_TYPE_UPLOAD_RESPOND;
        memcpy(pdu->caMsg, data.data(), data.size());

        // 发送文件数据
        emit fileDataReady(pdu);
    }

}
