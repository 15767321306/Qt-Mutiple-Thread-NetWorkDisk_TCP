#ifndef FILETHREAD_H
#define FILETHREAD_H

#include <QObject>
#include <QFile>
#include "protocol.h"
#include "mysocket.h"
class MySocket;
class FileThread : public QObject
{
    Q_OBJECT
public:
    explicit FileThread(MySocket* socket,QObject *parent = nullptr);
    Q_INVOKABLE void startReceivingFile(TransFile* transfile, QByteArray data); // 使用引用传递TransFile
public slots:
    void handleDownload(const QString &filePath, const QString &fileName,const QString &Tip); // 处理下载请求
    void sendFileData(); // 发送文件数据
signals:
    void downloadRespond(PDU* pdu); // 下载响应信号
    void fileDataReady(PDU* pdu); // 文件数据准备好信号
signals:
    void fileReceived(PDU* pdu); // 文件接收成功或失败的信号
private:
    QFile file; // 文件对象
    QFile *downFile;
    MySocket *mySocket; // 指向当前 MySocket 的指针
    //QTimer *m_timer; //
};

#endif // FILETHREAD_H
