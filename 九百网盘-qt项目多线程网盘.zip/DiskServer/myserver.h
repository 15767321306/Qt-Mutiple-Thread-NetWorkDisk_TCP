#ifndef MYSERVER_H
#define MYSERVER_H

#include <QTcpServer>
#include <QMap>
#include "mysocket.h"
#include "ConnectionThread.h"
class MyServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit MyServer(QObject *parent = nullptr);
    static MyServer& getInstance();
    void ForWardMsg(const char * name, PDU *pdu);
signals:
    void pushMsg(PDU *pdu);
protected:
    void incomingConnection(qintptr socketDescriptor) override;
private:
    QMap<int, MySocket*> clientMap; // 保存所有连接的客户端
    QMutex mutex;
};

#endif // MYSERVER_H
