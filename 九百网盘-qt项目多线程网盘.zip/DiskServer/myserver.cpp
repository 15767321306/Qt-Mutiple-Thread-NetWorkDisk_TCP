#include "myserver.h"
#include <QDebug>
MyServer::MyServer(QObject *parent)
    : QTcpServer{parent}
{
    //connect(this,&MyServer::pushMsg,MySocket::getInstance(),&MySocket::onForwardMsg);

}

MyServer &MyServer::getInstance()
{
    static MyServer instance;
    return instance;
}

void MyServer::ForWardMsg(const char *name, PDU *pdu) {
    if(name == NULL || pdu == NULL)
    {
        return;
    }

    if(clientMap.isEmpty())
    {
        qDebug() << "No clients connected.";
        return;
    }

    QMutexLocker locker(&mutex); // 锁住互斥量
    if(strcmp(name,"all") == 0)//群发
    {
        qDebug() << "Forwarding message to all clients...";
        for(auto it = clientMap.begin(); it != clientMap.end(); it++)
        {
            if(it.value()->getName() == pdu->caData)//不发给自己
            {
                continue;
            }
            qDebug() << "公屏聊天对象:" << it.value()->getName();

            // emit pushMsg(pdu);
            // it.value()->flush();//确保数据发送

            QMetaObject::invokeMethod(it.value(), "sendMessage", Qt::QueuedConnection,
                                      Q_ARG(PDU*, pdu));
            return;
        }
    }
    else //私聊
    {

        QString targetName = QString::fromUtf8(name);
        for(auto it = clientMap.begin(); it != clientMap.end(); it++)
        {

            if(targetName == it.value()->getName())
            {
                qDebug() << "私聊对象:" << name;

                QMetaObject::invokeMethod(it.value(), "sendMessage", Qt::QueuedConnection,
                                          Q_ARG(PDU*, pdu));
                return;
            }
        }
    }
}

void MyServer::incomingConnection(qintptr socketDescriptor) { //当有新的连接进入时，会调用这个函数
    qDebug() << "New connection" << socketDescriptor;
    ConnectionThread *thread = new ConnectionThread(socketDescriptor, &clientMap, this);
    connect(thread, &ConnectionThread::finished, thread, &QObject::deleteLater);
    thread->start();
}
