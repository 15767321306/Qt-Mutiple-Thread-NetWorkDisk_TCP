#include "diskserver.h"
#include "ui_diskserver.h"

#include <QDir>
#include <QFile>
#include <myServer.h>

DiskServer::DiskServer(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::DiskServer)
{
    ui->setupUi(this);
    ip = "127.0.0.1";
    port = 9999;
    LoadConfig();//加载配置
    InitConnected();//初始化连接
}

DiskServer &DiskServer::getInstance()
{
    static DiskServer instance;
    return instance;
}

DiskServer::~DiskServer()
{
    delete ui;
}

void DiskServer::LoadConfig()
{
    QFile file(":/server.config");
    file.open(QIODevice::ReadOnly);
    if (!file.isOpen())
    {
        qDebug() << "Failed to open config file.";
        return;
    }
    QTextStream in(&file);
    ip = in.readLine();//读取ip
    port = in.readLine().toUShort();//读取端口
    SavePath = in.readLine();//读取保存路径
    m_SharePath = in.readLine();//读取共享路径
    QDir dir;
    if(dir.mkpath(m_SharePath))
    {
        qDebug() << "创建共享目录成功.";
    }
    file.close();
}

QString DiskServer::getRootPath()
{
    return SavePath;
}

QString DiskServer::getSharePath()
{
    return m_SharePath;
}

void DiskServer::setSharePath(const QString &sharePath)
{
    m_SharePath = sharePath;
}

void DiskServer::InitConnected()
{
    if (!MyServer::getInstance().listen(QHostAddress(ip), port)) {
        qDebug() << "Server could not start!";
        return;
    }
    qDebug() << "Server started at "<<ip<<":"<<port;
}
