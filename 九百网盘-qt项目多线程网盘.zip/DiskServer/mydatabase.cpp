#include "mydatabase.h"
#include <QMutex>
#include <QSqlError>

MyDataBase::MyDataBase(QObject *parent)
    : QObject{parent}
{
    // 不再在构造函数中初始化连接
}

MyDataBase &MyDataBase::getInstance()
{
    static QMutex mutex;
    QMutexLocker locker(&mutex); // RAII，自动管理锁的释放
    static MyDataBase instance;
    return instance;
}

MyDataBase::~MyDataBase()
{
    // 析构函数中移除所有数据库连接
    QStringList connectionNames = QSqlDatabase::connectionNames();
    for(const QString& connName : connectionNames)
    {
        if(QSqlDatabase::contains(connName))
        {
            QSqlDatabase db = QSqlDatabase::database(connName);
            db.close();
            QSqlDatabase::removeDatabase(connName);
            qDebug() << "数据库连接已移除：" << connName;
        }
    }
}

bool MyDataBase::initDB(const QString& connectionName)
{
    QMutexLocker locker(&mutex_);

    QSqlDatabase db;

    if (QSqlDatabase::contains(connectionName))
    {
        db = QSqlDatabase::database(connectionName);
        if (!db.isOpen())
        {
            db.setHostName("localhost");
            db.setUserName("root");
            db.setPassword("Mzc15702003");
            db.setDatabaseName("networkdisk");
            if (!db.open())
            {
                QMessageBox::critical(nullptr, "数据库打开", "复用数据库连接失败: " + db.lastError().text());
                return false;
            }
        }
    }
    else
    {
        db = QSqlDatabase::addDatabase("QMYSQL", connectionName);
        db.setHostName("localhost");
        db.setUserName("root");
        db.setPassword("Mzc15702003");
        db.setDatabaseName("networkdisk");

        if(!db.open())
        {
            QMessageBox::critical(nullptr, "数据库打开", "数据库打开失败: " + db.lastError().text());
            return false;
        }
    }

    qDebug() << "数据库连接初始化成功：" << connectionName;
    return true;
}

bool MyDataBase::RegisterRequest(const char* name, const char* password, const QString& connectionName)
{

    if(name == NULL || password == NULL)
    {
        return false;
    }

    // 使用连接名创建查询
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "RegisterRequest: 连接不存在：" << connectionName;
            return false;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "RegisterRequest: 数据库连接未打开：" << connectionName;
        return false;
    }
    QSqlQuery query(db);
    QString strQuery = QString("INSERT INTO userInfo(name, pwd) VALUES ('%1', '%2')").arg(name).arg(password);
    return query.exec(strQuery);
}

bool MyDataBase::LoginRequest(const char *name, const char *password, const QString &connectionName)
{
    if(name == NULL || password == NULL)
    {
        return false;
    }

    // 使用连接名创建查询
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "LoginRequest: 连接不存在：" << connectionName;
            return false;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "LoginRequest: 数据库连接未打开：" << connectionName;
        return false;
    }
    QSqlQuery query(db);
    QString strQuery = QString("SELECT * FROM userInfo WHERE name = '%1' AND pwd = '%2' AND online = 0 ").arg(name).arg(password);
    query.exec(strQuery);
    if(query.next())
    {
        //更新用户在线状态
        QString strQuery = QString("UPDATE userInfo SET online = 1 WHERE name = '%1' AND pwd = '%2'").arg(name).arg(password);
        return query.exec(strQuery);
    }
    else
    {
        return false;
    }
}

bool MyDataBase::UseExit(const char *name, const char *password, const QString &connectionName)
{
    if(name == NULL || password == NULL)
    {
        return false;
    }

    // 使用连接名创建查询
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "UseExit: 连接不存在：" << connectionName;
            return false;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "UseExit: 数据库连接未打开：" << connectionName;
        return false;
    }

    QSqlQuery query(db);
    QString strQuery = QString("SELECT * FROM userInfo WHERE name = '%1' AND pwd = '%2'").arg(name).arg(password);
    query.exec(strQuery);
    if(query.next())
    {
        //更新用户在线状态
        QString strQuery = QString("UPDATE userInfo SET online = 0 WHERE name = '%1' AND pwd = '%2'").arg(name).arg(password);
        return query.exec(strQuery);
    }
    else
    {
        return false;
    }
}

QStringList MyDataBase::OnlineFriends(PDU *pdu, const QString &connectionName)
{
    // 使用连接名创建查询
    QStringList result;
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "OnlineFriends: 连接不存在：" << connectionName;
            return result;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "OnlineFriends: 数据库连接未打开：" << connectionName;
        return result;
    }
    QSqlQuery query(db);
    QString strQuery = QString("SELECT * FROM userInfo WHERE online = 1");
    query.exec(strQuery);

    result.clear(); // 清除内容
    while(query.next())
    {
        QString str = query.value(1).toString();
        result.append(str);
    }
    return result;
}

int MyDataBase::AddFriend(const char *name, const char *friendName, const QString &connectionName)
{
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "OnlineFriends: 连接不存在：" << connectionName;
            return -1;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "OnlineFriends: 数据库连接未打开：" << connectionName;
        return -1;
    }

    if(name == NULL || friendName == NULL)
    {
        return -1; // 用户名或好友名为空
    }

    QSqlQuery query(db);
    QString strQuery = QString("select * from friendInfo "
                               "where (id = (select id from userInfo where name = \'%1\') and "
                               "friendId = (select id from userInfo where name = \'%2\')) or "  // 好友是双向的，数据库只存了单向，注意是or关系
                               "(id = (select id from userInfo where name = \'%3\') and "
                               "friendId = (select id from userInfo where name = \'%4\'))")
                           .arg(name).arg(friendName).arg(friendName).arg(name);
    //qDebug() << strQuery;
    query.exec(strQuery);
    if(query.next())
    {
        return 3; // 双方已经是好友
    }
    else // 不是好友
    {
        return handleSearchUser(friendName,connectionName); // 查询对方，存在并在线返回1，存在不在线返回0，不存在该用户返回2
    }
}

int MyDataBase::handleSearchUser(const char *name, const QString &connectionName)
{
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "OnlineFriends: 连接不存在：" << connectionName;
            return -1;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "OnlineFriends: 数据库连接未打开：" << connectionName;
        return -1;
    }
    QSqlQuery query(db);
    QString strQuery = QString("select * from userInfo where name = \'%1\'").arg(name);
    query.exec(strQuery);
    if(query.next())
    {
        int onlineIndex = query.record().indexOf("online"); // 假设列名为 "online"
        if (onlineIndex != -1 && query.value(onlineIndex).toInt() == 1)
        {
            return 1; // 对方在线
        }
        else
        {
            return 0; // 对方不在线
        }
    }
    else
    {
        return 2; // 不存在该用户
    }

}

void MyDataBase::AgreeAddFriend(const char *name, const char *friendName, const QString &connectionName)
{
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "OnlineFriends: 连接不存在：" << connectionName;
            return;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "OnlineFriends: 数据库连接未打开：" << connectionName;
        return;
    }

    QSqlQuery query(db);
    int sourceUserId = -1, addedUserId = -1;
    // 查找用户对应id
    addedUserId = getIdFromName(name,connectionName);
    sourceUserId = getIdFromName(friendName,connectionName);

    QString strQuery = QString("insert into friendInfo values(%1, %2) ").arg(sourceUserId).arg(addedUserId);

    query.exec(strQuery);

}

int MyDataBase::getIdFromName(const char *name, const QString &connectionName)
{
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "OnlineFriends: 连接不存在：" << connectionName;
            return -1;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "OnlineFriends: 数据库连接未打开：" << connectionName;
        return -1;
    }

    QSqlQuery query(db);
    QString strQuery = QString("SELECT id FROM userInfo WHERE name = \'%1\'").arg(name);
    query.exec(strQuery);
    if(query.next())
    {
        return query.value(0).toInt();
    }
    else
    {
        return -1;
    }
}

QStringList MyDataBase::SearchUsers(const char *name, const QString &connectionName)
{
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "OnlineFriends: 连接不存在：" << connectionName;
            return QStringList();
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "OnlineFriends: 数据库连接未打开：" << connectionName;
        return QStringList();
    }

    QSqlQuery query(db);
    QString strQuery = QString("SELECT name FROM userInfo WHERE name like '%%1%'").arg(name);
    query.exec(strQuery);
    QStringList result;
    while(query.next())
    {
        QString str = query.value(0).toString();
        result.append(str);
    }
    return result;
}

QStringList MyDataBase::FlushFriends(const char *name, const QString &connectionName)
{
    QStringList FriendsList;
    FriendsList.clear();
    if(name == NULL)
    {
        return FriendsList;
    }
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "OnlineFriends: 连接不存在：" << connectionName;
            return QStringList();
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "OnlineFriends: 数据库连接未打开：" << connectionName;
        return QStringList();
    }


    QSqlQuery query(db);
    QString strQuery = QString("SELECT id FROM userInfo WHERE name = '%1'").arg(name);
    int Sid = -1;
    query.exec(strQuery);
    if(query.next())
    {
        Sid = query.value(0).toInt();
        qDebug() << "Sid = " << Sid;
    }

    strQuery = QString("select name,online from userInfo where id in ((select friendId from friendInfo where id = '%1') union (select id from friendInfo where friendId = '%2'))").arg(Sid).arg(Sid);

    query.exec(strQuery);
    while(query.next())
    {
        QString str = query.value(0).toString();
        FriendsList.append(str);
        str = query.value(1).toString();
        FriendsList.append(str);
    }

    return FriendsList;
}

bool MyDataBase::DeleteFriend(const char *name, const char *friendName, const QString &connectionName)
{
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "DeleteFriend: 连接不存在：" << connectionName;
            return false;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "DeleteFriend: 数据库连接未打开：" << connectionName;
        return false;
    }

    // 获取两个用户的ID
    int iDelId = -1;
    int iSouId = -1;
    QString strQuery = QString("SELECT id, name FROM userInfo WHERE name IN ('%1', '%2')").arg(name).arg(friendName);
    qDebug() << "DeleteFriend: 查询两个用户的ID:" << strQuery;
    QSqlQuery query(db);

    if(!query.exec(strQuery)) {
        qDebug() << "DeleteFriend: 执行查询失败:" << query.lastError();
        return false;
    }

    while(query.next())
    {
        QString userName = query.value(1).toString();
        int userId = query.value(0).toInt();
        if(userName == name) {
            iDelId = userId;
        } else if(userName == friendName) {
            iSouId = userId;
        }
    }

    if(iDelId == -1 || iSouId == -1) {
        qDebug() << "DeleteFriend: 无法找到一个或两个用户的ID。";
        return false;
    }

    qDebug() << "DeleteFriend: 准备删除好友关系，ID1:" << iDelId << "ID2:" << iSouId;

    db.transaction();

    // 删除 id1 -> id2
    QSqlQuery deleteQuery1(db);
    deleteQuery1.prepare("DELETE FROM friendInfo WHERE id = :id1 AND friendId = :id2");
    deleteQuery1.bindValue(":id1", iDelId);
    deleteQuery1.bindValue(":id2", iSouId);
    bool success1 = deleteQuery1.exec();
    if(!success1) {
        qDebug() << "DeleteFriend: 删除 id1->id2 失败:" << deleteQuery1.lastError();
        db.rollback();
        return false;
    }

    // 删除 id2 -> id1
    QSqlQuery deleteQuery2(db);
    deleteQuery2.prepare("DELETE FROM friendInfo WHERE id = :id2 AND friendId = :id1");
    deleteQuery2.bindValue(":id2", iSouId);
    deleteQuery2.bindValue(":id1", iDelId);
    bool success2 = deleteQuery2.exec();
    if(!success2) {
        qDebug() << "DeleteFriend: 删除 id2->id1 失败:" << deleteQuery2.lastError();
        db.rollback();
        return false;
    }

    db.commit();
    qDebug() << "DeleteFriend: 成功删除好友关系。";

    return true;
}

bool MyDataBase::isOnline(const char *name, const QString &connectionName)
{
    QSqlDatabase db;
    {
        QMutexLocker locker(&mutex_);
        if (QSqlDatabase::contains(connectionName))
        {
            db = QSqlDatabase::database(connectionName);
        }
        else
        {
            qDebug() << "DeleteFriend: 连接不存在：" << connectionName;
            return false;
        }
    }

    if (!db.isOpen())
    {
        qDebug() << "DeleteFriend: 数据库连接未打开：" << connectionName;
        return false;
    }

    QString strQuery = QString("SELECT online FROM userInfo WHERE name = '%1'").arg(name);
    qDebug() << "查看某人的在线状态:" << strQuery;
    QSqlQuery query(db);
    if(!query.exec(strQuery)) {
        qDebug() << "查询在线状态失败:" << query.lastError();
        return false;
    }

    if(query.next())
    {
        qDebug() << "查询在线状态成功"<< query.value(0).toBool();
        return query.value(0).toBool();//返回在线状态
    }
    else
    {
        return false;
    }

}


