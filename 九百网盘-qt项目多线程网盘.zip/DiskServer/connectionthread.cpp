#include "ConnectionThread.h"
#include <QDebug>
#include <mySocket.h>

ConnectionThread::ConnectionThread(int socketDescriptor, QMap<int, MySocket*> *clientMap, QObject *parent)
    : QThread(parent), socketDescriptor(socketDescriptor), clientMap(clientMap) // 初始化 clientMap
{
    //connect(&MyServer::getInstance(),&MyServer::pushMsg,&MySocket::getInstance(),&MySocket::onForwardMsg);
}

ConnectionThread::~ConnectionThread()
{
    // 在销毁时停止线程并等待其退出
    qDebug() << "Thread for socket" << socketDescriptor << " is terminating.";
    quit();  // 退出事件循环
    wait();  // 等待线程结束
}

void ConnectionThread::run() {
    MySocket *socket = new MySocket(clientMap); // 创建一个 socket
    if (!socket->setSocketDescriptor(socketDescriptor)) {
        qDebug() << "Failed to set socket descriptor";
        delete socket;
        return;
    }

    // 将 socket 插入到 clientMap 中
    clientMap->insert(socketDescriptor, socket); // 插入到 clientMap 中

    exec(); // 启动事件循环
}
