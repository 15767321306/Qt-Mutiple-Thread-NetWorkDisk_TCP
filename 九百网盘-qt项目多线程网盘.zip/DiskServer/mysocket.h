#ifndef MYSOCKET_H
#define MYSOCKET_H

#include <QTcpSocket>
#include <QMap>
#include <QMutex>
#include <QTimer>
#include "filethread.h"
#include "protocol.h"
#include <QThread>
class FileThread;
class MySocket : public QTcpSocket
{
    Q_OBJECT
public:
    explicit MySocket(QMap<int, MySocket*> *clientMap, QObject *parent = nullptr);
    int getSocketDescriptor();
    QString getName()const;
    void setName(const QString &name);
    void ForwordMsg(const char* name,PDU *pdu);
    QMap<int, MySocket*> *getClientMap() const;
public slots:
    void PDUHandle(PDU *pdu);
    //void onForwardMsg(PDU *pdu);
    void sendMessage(PDU *pdu) {
        if (pdu) {
            this->write((char*)pdu,pdu->uiPDULen);
            this->flush();
        }
    }
    void onDownloadRespond(PDU* pdu); // 下载响应槽
    void onFileDataReady(PDU* pdu); // 文件数据准备好槽
private slots:
    void onReadyRead();
    void onDisconnected();
signals:
    void dataHanlde(PDU *pdu);
    void forwardMsg(const char* name,PDU *pdu);
private:
    QMap<int, MySocket*> *clientMap; // 保存客户端连接的映射表
    QString m_Name;
    QMutex mutex;
    TransFile *m_transFile;
    FileThread *fileThread;
    QThread *thread;
    QByteArray m_buffer; // 用于存储接收的未处理数据
    QFile *m_downfile; // 用于存储下载的文件
    //QList<QString> UploadUserName;
public:
    PDU* HandleRegister(PDU *request);
    PDU* HandleLogin(QString &m_Name,PDU* pdu);
    void HandleExit(PDU* pdu);
    PDU* HandleOnlineFriends(PDU* pdu);
    PDU* HandleADDFriend(PDU* pdu);
    void HandleAgreeADD(PDU* pdu);
    void HandleRejuctADD(PDU* pdu);
    PDU* HandleSearchUsers(PDU* pdu);
    PDU* HandleFlushFriends(PDU* pdu);
    PDU* HandleDeleteFriend(PDU* pdu);
    void HandleSendMessage(PDU* pdu);
    void HandlePrivateChat(PDU* pdu);
    PDU* HandleMkdir(PDU* pdu);
    PDU* HandleLS(PDU* pdu);
    PDU* HandleUpload(PDU* pdu,TransFile* transFile);
    PDU* HandleDeleteFile(PDU* pdu);
    PDU* HandleRenameFile(PDU* pdu);
    PDU* HandleLSShareArea(PDU* pdu);
    void HandleDownload(PDU *pdu);
};


#endif // MYSOCKET_H

