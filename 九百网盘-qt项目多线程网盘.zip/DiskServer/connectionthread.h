#ifndef CONNECTIONTHREAD_H
#define CONNECTIONTHREAD_H

#include <QThread>
#include <QMap>
#include "mySocket.h"
#include "myserver.h"
class ConnectionThread : public QThread {
    Q_OBJECT
public:
    explicit ConnectionThread(int socketDescriptor, QMap<int, MySocket*> *clientMap, QObject *parent = nullptr);
    ~ConnectionThread();
protected:
    void run() override;
private:
    int socketDescriptor;
    QMap<int, MySocket*> *clientMap; // 指向共享的客户端映射表
};

#endif // CONNECTIONTHREAD_H
