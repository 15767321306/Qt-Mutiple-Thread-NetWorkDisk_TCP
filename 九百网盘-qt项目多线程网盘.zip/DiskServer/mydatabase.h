#ifndef MYDATABASE_H
#define MYDATABASE_H

#include <QWidget>
#include "protocol.h"
#include <QSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QMessageBox>
#include <QMutex>
#include <QSqlRecord>
class MyDataBase : public QObject
{
    Q_OBJECT
public:
    static MyDataBase& getInstance();
    ~MyDataBase();
    bool initDB(const QString& connectionName);
    bool RegisterRequest(const char* name, const char* password, const QString& connectionName);
    bool LoginRequest(const char* name, const char* password, const QString& connectionName);
    bool UseExit(const char* name, const char* password, const QString& connectionName);
    QStringList OnlineFriends(PDU* pdu, const QString& connectionName);
    int AddFriend(const char* name, const char* friendName, const QString& connectionName);
    int handleSearchUser(const char *name, const QString& connectionName);
    void AgreeAddFriend(const char* name, const char* friendName, const QString& connectionName);
    int getIdFromName(const char* name, const QString& connectionName);
    QStringList SearchUsers(const char* name, const QString& connectionName);
    QStringList FlushFriends(const char* name, const QString& connectionName);
    bool DeleteFriend(const char* name, const char* friendName, const QString& connectionName);
    bool isOnline(const char* name, const QString& connectionName);
signals:
private:
    explicit MyDataBase(QObject *parent = nullptr);
    //QSqlDatabase m_db; // 连接数据库
    QMutex mutex_;
};

#endif // MYDATABASE_H
