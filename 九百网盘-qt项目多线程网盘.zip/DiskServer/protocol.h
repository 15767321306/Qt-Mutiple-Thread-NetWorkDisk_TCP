#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <QFile>
#include <QString>
#include <QDateTime>
#include <cstdlib> // 使用malloc和free
#include <cstring> // 使用memset
#include <cstdio>  // 使用exit
#include <QString>
#include <QMetaType>
typedef unsigned int uint;

#define REGIST_OK "注册成功"
#define REGIST_FAIL "注册失败"

#define LOGIN_OK "登录成功"
#define LOGIN_FAIL "登录失败"

#define DATABASE_FAL "数据库操作失败"
#define ADD_FRIEND_OFFLINE "对方不在线"
#define ADD_FRIEND_ONLINE "添加成功"
#define ADD_FRIEND_EMPTY "添加为空"
#define ADD_FRIEND_FAIL "你们已经是好友了"

#define DELETE_FRIEND_OK "删除成功"
#define DELETE_FRIEND_FAIL "删除失败"

#define PRIVATE_CHAT_OK "私聊成功"
#define PRIVATE_CHAT_FAIL "私聊失败"

#define MKDIR_OK "创建成功"
#define MKDIR_FAIL "创建失败"

#define PATH_NOT_EXIST "路径不存在"

#define UPLOAD_FILE_START "上传文件开始"
#define UPLOAD_FILE_OK "上传文件成功"
#define UPLOAD_FILE_FAIL "上传文件失败"
#define DELETE_FILE_OK "删除文件成功"
#define DELETE_FILE_FAIL "删除文件失败"
#define RENAME_FILE_OK "重命名成功"
#define RENAME_FILE_FAIL "重命名失败"

#define DOWNLOAD_FILE_START "下载文件开始"
#define DOWNLOAD_FILE_OK "下载文件成功"
#define DOWNLOAD_FILE_FAIL "下载文件失败"

#define DOWNLOAD_FILE_SHARE "分享文件下载"

enum ENUM_MSG_TYPE {
    ENUM_MSG_TYPE_MIN = 0,

    // 用户相关
    ENUM_MSG_TYPE_REGIST_REQUEST,
    ENUM_MSG_TYPE_REGIST_RESPOND,
    ENUM_MSG_TYPE_LOGIN_REQUEST,
    ENUM_MSG_TYPE_LOGIN_RESPOND,
    ENUM_MSG_TYPE_USER_EXIT,


    // 好友相关
    ENUM_MSG_TYPE_ONLINE_FRIENDS_REQUEST,
    ENUM_MSG_TYPE_ONLINE_FRIENDS_RESPOND,
    ENUM_MSG_TYPE_ADD_FRIENDS_REQUEST,
    ENUM_MSG_TYPE_ADD_FRIENDS_RESPOND,
    ENUM_MSG_TYPE_ADD_FRIENDS_AGREE_RESPOND,
    ENUM_MSG_TYPE_ADD_FRIENDS_REJUCT_RESPOND,
    ENUM_MSG_TYPE_SEARCH_USERS_REQUEST,
    ENUM_MSG_TYPE_SEARCH_USERS_RESPOND,
    ENUM_MSG_TYPE_FLUSH_FRIENDS_REQUEST,
    ENUM_MSG_TYPE_FLUSH_FRIENDS_RESPOND,
    ENUM_MSG_TYPE_DELETE_FRIENDS_REQUEST,
    ENUM_MSG_TYPE_DELETE_FRIENDS_RESPOND,

    // 聊天相关
    ENUM_MSG_TYPE_SEND_MESSAGE_REQUEST,
    ENUM_MSG_TYPE_SEND_MESSAGE_RESPOND,
    ENUM_MSG_TYPE_RPIVATECHAR_REQUEST,
    ENUM_MSG_TYPE_RPIVATECHAR_RESPOND,
    ENUM_MSG_TYPE_CHAT_MESSAGE,       // 聊天消息
    ENUM_MSG_TYPE_CHAT_MESSAGE_ACK,   // 聊天消息确认

    // 文件相关
    ENUM_MSG_TYPE_UPLOAD_FILE_REQUEST,
    ENUM_MSG_TYPE_UPLOAD_FILE_RESPOND,
    ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST,
    ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND,
    ENUM_MSG_TYPE_MKDIR_REQUEST,
    ENUM_MSG_TYPE_MKDIR_RESPOND,
    ENUM_MSG_TYPE_LS_REQUEST,
    ENUM_MSG_TYPE_LS_RESPOND,
    ENUM_MSG_TYPE_UPLOAD_REQUEST,
    ENUM_MSG_TYPE_UPLOAD_RESPOND,
    ENUM_MSG_TYPE_UPLOAD_BEGINNING,
    ENUM_MSG_TYPE_UPLOAD_FINISHED,
    ENUM_MSG_TYPE_DELETE_FILE_REQUEST,
    ENUM_MSG_TYPE_DELETE_FILE_RESPOND,
    ENUM_MSG_TYPE_RENAME_FILE_REQUEST,
    ENUM_MSG_TYPE_RENAME_FILE_RESPOND,


    // 文件信息
    ENUM_MSG_TYPE_FILE_INFO_REQUEST,
    ENUM_MSG_TYPE_FILE_INFO_RESPOND,


    //共享区文件
    ENUM_MSG_TYPE_LS_SHAREAREA_REQUEST,
    ENUM_MSG_TYPE_LS_SHAREAREA_RESPOND,

    // 错误处理
    ENUM_MSG_TYPE_ERROR,              // 错误信息

    ENUM_MSG_TYPE_MAX = 0x00ffffff,
};

// PDU结构
struct PDU {
    uint uiPDULen;       // 协议数据单元总大小
    uint uiMsgType;      // 消息类型
    char caData[128];    // 可变长度的数据
    uint uiMsgLen;       // 实际消息长度
    char caMsg[];        // 实际消息内容
};//弹性结构体
// 声明 PDU* 为 Qt 元类型
Q_DECLARE_METATYPE(PDU*)

// 文件信息结构
struct FileInfo {
    char caName[128];     // 文件名
    bool bIsDir;         // 是否为目录
    long long uiSize;    // 文件大小
    char caTime[128]; // 最后修改时间
};

// 错误消息结构
struct ErrorMessage {
    int errorCode;      // 错误代码
    char errorMsg[128]; // 错误信息
};
// 传输文件信息
struct TransFile
{
    QFile file; // 上传的文件
    qint64 iTotalSize; // 文件总大小
    qint64 iReceivedSize; // 已接收大小
    bool bTransform; // 是否正在传输文件
};
// 创建PDU的函数
PDU* mkPDU(uint uiMsgLen);

#endif // PROTOCOL_H
