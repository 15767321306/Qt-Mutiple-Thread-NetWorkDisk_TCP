#ifndef DISKSERVER_H
#define DISKSERVER_H

#include "myserver.h"

#include <QWidget>
#include "mysocket.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class DiskServer;
}
QT_END_NAMESPACE

class DiskServer : public QWidget
{
    Q_OBJECT

public:
    DiskServer(QWidget *parent = nullptr);
    static DiskServer& getInstance();
    ~DiskServer();
    void LoadConfig();
    QString getRootPath();

    QString getSharePath();
    void setSharePath(const QString &sharePath);
    void InitConnected();
private:
    Ui::DiskServer *ui;
    QString ip;
    quint16 port;
    QString SavePath;
    QString m_SharePath;
    //MyServer server;
};
#endif // DISKSERVER_H
