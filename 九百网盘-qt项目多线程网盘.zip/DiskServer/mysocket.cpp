#include "mydatabase.h"
#include "myserver.h"
#include "mysocket.h"
#include "diskserver.h"
#include <QDir>
#include <QTimer>


MySocket::MySocket(QMap<int, MySocket*> *clientMap, QObject *parent)
    : QTcpSocket(parent), clientMap(clientMap)
{
    m_transFile = new TransFile();
    fileThread = new FileThread(this);
    thread = new QThread();
    m_downfile = new QFile();

    // 将TransFile的引用传递给fileThread
    fileThread->moveToThread(thread);
    thread->start(); // 启动线程
    connect(thread, &QThread::finished, fileThread, &FileThread::deleteLater);
    connect(this, &MySocket::readyRead, this, &MySocket::onReadyRead);
    connect(this, &MySocket::disconnected, this, &MySocket::onDisconnected);
    connect(this,&MySocket::dataHanlde,this,&MySocket::PDUHandle);
    connect(fileThread, &FileThread::fileReceived, this, [this](PDU* res) {
        if (res != nullptr) {
            write((char*)res, res->uiPDULen);
            free(res);
        }
    });

    connect(fileThread, &FileThread::downloadRespond, this, &MySocket::onDownloadRespond);
    connect(fileThread, &FileThread::fileDataReady, this, &MySocket::onFileDataReady);


   // connect(thread, &QThread::started, fileThread, &FileThread::run);
}

int MySocket::getSocketDescriptor() { //获取socket描述符
    return socketDescriptor();
}

QString MySocket::getName() const
{
    return m_Name;
}

void MySocket::setName(const QString &name)
{
    m_Name = name;
}

void MySocket::PDUHandle(PDU *pdu)
{
    PDU* respdu = NULL;
    switch (pdu->uiMsgType) {
        case ENUM_MSG_TYPE_REGIST_REQUEST:
        {
            respdu = HandleRegister(pdu);
        }
        break;
        case ENUM_MSG_TYPE_LOGIN_REQUEST:
        {

            respdu = HandleLogin(m_Name,pdu);
        }
        break;
        case ENUM_MSG_TYPE_USER_EXIT:
        {
            qDebug() << "User exit: ";
            HandleExit(pdu);
        }
        break;
        case ENUM_MSG_TYPE_ONLINE_FRIENDS_REQUEST:
        {
            respdu = HandleOnlineFriends(pdu);
        }
        break;
        case ENUM_MSG_TYPE_ADD_FRIENDS_REQUEST:
        {
            respdu = HandleADDFriend(pdu);
        }
        break;
        case ENUM_MSG_TYPE_ADD_FRIENDS_AGREE_RESPOND:
        {
            HandleAgreeADD(pdu);
        }
        break;
        case ENUM_MSG_TYPE_ADD_FRIENDS_REJUCT_RESPOND:
        {
            HandleRejuctADD(pdu);
        }
        break;
        case ENUM_MSG_TYPE_SEARCH_USERS_REQUEST:
        {
            respdu = HandleSearchUsers(pdu);
        }
        break;
        case ENUM_MSG_TYPE_FLUSH_FRIENDS_REQUEST:
        {
            respdu = HandleFlushFriends(pdu);
        }
        break;
        case ENUM_MSG_TYPE_DELETE_FRIENDS_REQUEST:
        {
            respdu = HandleDeleteFriend(pdu);
        }
        break;
        case ENUM_MSG_TYPE_SEND_MESSAGE_REQUEST:
        {
            HandleSendMessage(pdu);
        }
        break;
        case ENUM_MSG_TYPE_RPIVATECHAR_REQUEST:
        {
            HandlePrivateChat(pdu);
        }
        break;
        case ENUM_MSG_TYPE_MKDIR_REQUEST:
        {
            respdu = HandleMkdir(pdu);
        }
        break;
        case ENUM_MSG_TYPE_LS_REQUEST:
        {
            respdu = HandleLS(pdu);
        }
        break;
        case ENUM_MSG_TYPE_UPLOAD_REQUEST:
        {
            respdu = HandleUpload(pdu,m_transFile);
        }
        break;
        case ENUM_MSG_TYPE_UPLOAD_BEGINNING:
        {
            qDebug() << "开始接收文件";
        }
        break;
        case ENUM_MSG_TYPE_DELETE_FILE_REQUEST:
        {
            respdu = HandleDeleteFile(pdu);
        }
        break;
        case ENUM_MSG_TYPE_RENAME_FILE_REQUEST:
        {
            respdu = HandleRenameFile(pdu);
        }
        break;
        case ENUM_MSG_TYPE_LS_SHAREAREA_REQUEST:
        {
            respdu = HandleLSShareArea(pdu);
        }
        break;
        case ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST:
        {
            HandleDownload(pdu);
        }
        break;
    // 处理其他消息类型...
    default:
        break;
    }

    if (respdu != NULL) {
        write((char*)respdu , respdu->uiPDULen);
        free(respdu);
        respdu = NULL;
    }
}

void MySocket::onReadyRead() {
    // 将新接收的数据追加到缓冲区
    m_buffer.append(this->readAll());

    // 循环解析缓冲区中的 PDU
    while (true) {
        // 检查缓冲区是否至少有 sizeof(uint) 字节来读取 uiPDULen
        if (m_buffer.size() < sizeof(uint)) {
            // 数据不足，等待更多数据到达
            break;
        }

        // 从缓冲区读取 uiPDULen
        uint uiPDULen;
        memcpy(&uiPDULen, m_buffer.constData(), sizeof(uint));

        // 检查 uiPDULen 是否合理
        if (uiPDULen < sizeof(PDU)) {
            qDebug() << "接收到的 PDU 长度无效：" << uiPDULen;
            // 这里可以选择断开连接或清空缓冲区
            this->disconnectFromHost();
            return;
        }

        // 检查缓冲区中是否有完整的 PDU 数据
        if (m_buffer.size() < uiPDULen) {
            // 数据不足，等待更多数据到达
            break;
        }

        // 提取完整的 PDU 数据
        QByteArray pduData = m_buffer.mid(0, uiPDULen);
        m_buffer.remove(0, uiPDULen); // 移除已处理的数据

        // 解析 PDU 结构
        PDU* pdu = (PDU*)pduData.constData();

        // 处理不同类型的 PDU
        if (m_transFile->bTransform) {
            qDebug() << "开始接收文件";

            // 确保 uiMsgLen 不超过 caMsg 的实际大小
            if (pdu->uiMsgLen > 0 && pdu->uiMsgLen <= (uiPDULen - sizeof(PDU))) {
                QByteArray fileData = QByteArray(pdu->caMsg, pdu->uiMsgLen);
                qDebug() << "实际文件数据大小：" << fileData.size();

                // 将副本传递给 fileThread 处理
                QMetaObject::invokeMethod(fileThread, "startReceivingFile",
                                          Qt::QueuedConnection,
                                          Q_ARG(TransFile*, m_transFile),
                                          Q_ARG(QByteArray, fileData));
            } else {
                qDebug() << "文件数据长度不正确或超出范围：" << pdu->uiMsgLen;
            }
        } else {

            emit dataHanlde(pdu);
        }
        // 注意：由于 pduData 是 QByteArray 的一部分，pdu 的内存由 QByteArray 管理
        // 无需手动释放 pdu
    }
}

void MySocket::onDisconnected() { //断开连接
    qDebug() << "Client disconnected:" << socketDescriptor();
    close();

    // 从客户端映射表中移除
    clientMap->remove(socketDescriptor());
    deleteLater();
}

void MySocket::ForwordMsg(const char *name, PDU *pdu)
{
    if(name == NULL || pdu == NULL)
    {
        return;
    }

    if(clientMap->isEmpty())
    {
        qDebug() << "No clients connected.";
        return;
    }

    QMutexLocker locker(&mutex); // 锁住互斥量
    if(strcmp(name,"all") == 0)//群发
    {
        qDebug() << "Forwarding message to all clients...";
        for(auto it = clientMap->begin(); it != clientMap->end(); it++)
        {
            if(it.value()->getName() == name)//不发给自己
            {
                continue;
            }
            qDebug() << "Forwarding message to client:" << it.value()->getName();
            it.value()->write((char*)pdu, pdu->uiPDULen);
            it.value()->flush();//确保数据发送
            return;
        }
    }
    else //私聊
    {
        qDebug() << "Forwarding message to client:" << name;
        QString targetName = QString::fromUtf8(name);
        for(auto it = clientMap->begin(); it != clientMap->end(); it++)
        {
            if(targetName == it.value()->getName())
            {
                it.value()->write((char*)pdu, pdu->uiPDULen);
                it.value()->flush();//确保数据发送
                return;
            }
        }
    }
}

QMap<int, MySocket *> *MySocket::getClientMap() const
{
    return clientMap;
}


PDU* MySocket::HandleRegister(PDU *request)
{
    qDebug() << "Register response: ";
    char name[64]={'\0'};
    char pwd[64]={'\0'};
    memcpy(name,request->caData,64);
    memcpy(pwd,request->caData+64,64);
    qDebug() << "name:" << name << "pwd:" << pwd;

    // 使用线程安全的数据库连接
    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return nullptr; // 数据库初始化失败
    }

    bool success = MyDataBase::getInstance().RegisterRequest(name, pwd, connectionName);

    // 创建响应 PDU
    PDU* respondPdu = mkPDU(0);
    respondPdu->uiMsgType = ENUM_MSG_TYPE_REGIST_RESPOND;
    memcpy(respondPdu->caData+64,name,64);//将名字返回回去，如果注册成功，则创建用户目录

    if (success) {
        qDebug() << "Register success";
        strcpy(respondPdu->caData, REGIST_OK);
    } else {
        qDebug() << "Register failed";
        strcpy(respondPdu->caData, REGIST_FAIL);
    }

    //QSqlDatabase::removeDatabase(connectionName); // 清理数据库连接
    return respondPdu;
}

PDU* MySocket::HandleLogin(QString &m_Name,PDU *pdu)
{
    qDebug() << "Login response: ";
    char name[64]={'\0'};
    char pwd[64]={'\0'};
    memcpy(name,pdu->caData,64);
    memcpy(pwd,pdu->caData+64,64);
    qDebug() << "name:" << name << "pwd:" << pwd;

    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return nullptr; // 数据库初始化失败
    }

    bool success = MyDataBase::getInstance().LoginRequest(name, pwd, connectionName);

    // 创建响应 PDU
    PDU* respondPdu = mkPDU(0);
    respondPdu->uiMsgType = ENUM_MSG_TYPE_LOGIN_RESPOND;

    if (success) {
        qDebug() << "login success";
        strcpy(respondPdu->caData, LOGIN_OK);
        m_Name = name;  // 使用实例调用 setName 方法
        QString path = QString("%1/%2").arg(DiskServer::getInstance().getRootPath()).arg(m_Name);
        memcpy(respondPdu->caData+64,path.toStdString().c_str(),64);
    } else {
        qDebug() << "login failed";
        strcpy(respondPdu->caData, LOGIN_FAIL);
    }

   // QSqlDatabase::removeDatabase(connectionName); // 清理数据库连接
    return respondPdu;
}

void MySocket::HandleExit(PDU *pdu)
{
    char username[64] = {'\0'};
    char password[64] = {'\0'};
    memcpy(username, pdu->caData, 64);
    memcpy(password, pdu->caData + 64, 64);

    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return; // 数据库初始化失败
    }

    bool success = MyDataBase::getInstance().UseExit(username, password, connectionName);
    //QSqlDatabase::removeDatabase(connectionName); // 清理数据库连接

    qDebug() << "User exit" << success;
}

PDU* MySocket::HandleOnlineFriends(PDU *pdu)
{
    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return nullptr; // 数据库初始化失败
    }


    QStringList onlineUsers = MyDataBase::getInstance().OnlineFriends(pdu, connectionName);

    uint uiMsgLen = onlineUsers.size() * 64; // 消息报文的长度

    PDU* respdu = mkPDU(uiMsgLen);
    respdu->uiMsgType = ENUM_MSG_TYPE_ONLINE_FRIENDS_RESPOND;

    for(int i = 0; i < onlineUsers.size(); i++)
    {
        memcpy(respdu->caMsg + i * 64, onlineUsers[i].toStdString().c_str(), onlineUsers[i].size());
        qDebug() << "Online user: " << onlineUsers[i];
    }

    return respdu;
}

PDU* MySocket::HandleADDFriend(PDU *pdu)
{
    qDebug() << "Add friend request: ";
    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return nullptr; // 数据库初始化失败
    }

    char username[64] = {'\0'};
    char friendname[64] = {'\0'};
    memcpy(username, pdu->caData, 64);
    memcpy(friendname, pdu->caData + 64, 64);

    int success = MyDataBase::getInstance().AddFriend(username, friendname, connectionName);
    qDebug() << "Add friend success:" << success;
    PDU *resPdu = mkPDU(0); // 响应消息
    resPdu -> uiMsgType = ENUM_MSG_TYPE_ADD_FRIENDS_RESPOND;
    switch(success)
    {
        case -1:
            strcpy(resPdu->caData, DATABASE_FAL);
            break;
        case 0:
            strcpy(resPdu->caData, ADD_FRIEND_OFFLINE);
            break;
        case 1:
            this->ForwordMsg(friendname, pdu);//转发消息
            strcpy(resPdu->caData, ADD_FRIEND_ONLINE);
            break;
        case 2:
            strcpy(resPdu->caData, ADD_FRIEND_EMPTY);
            break;
        case 3:
            strcpy(resPdu->caData, ADD_FRIEND_FAIL);
            break;
    }

    return resPdu;

}

void MySocket::HandleAgreeADD(PDU *pdu)
{
    char friendName[64]={'\0'};
    char userName[64]={'\0'};
    memcpy(friendName,pdu->caData,64);//对方
    memcpy(userName,pdu->caData+64,64);//我

    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return; // 数据库初始化失败
    }

    MyDataBase::getInstance().AgreeAddFriend(userName, friendName, connectionName);
    // 服务器需要转发给发送好友请求方其被同意的消息
    this->ForwordMsg(friendName,pdu);
}

void MySocket::HandleRejuctADD(PDU *pdu)
{
    char friendName[64] = {'\0'};
    memcpy(friendName,pdu->caData,64);

    this->ForwordMsg(friendName,pdu);
}

PDU *MySocket::HandleSearchUsers(PDU *pdu)
{
    qDebug()<<"Search Users";
    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return nullptr; // 数据库初始化失败
    }

    char searchName[64] = {'\0'};
    memcpy(searchName,pdu->caData,64);

    QStringList users = MyDataBase::getInstance().SearchUsers(searchName, connectionName);

    PDU* respdu = mkPDU(users.size() * 64);

    respdu->uiMsgType = ENUM_MSG_TYPE_SEARCH_USERS_RESPOND;

    for(int i = 0; i < users.size(); i++)
    {
        memcpy(respdu->caMsg + i * 64, users[i].toStdString().c_str(), users[i].size());
        qDebug() << "Search user: " << users[i];
    }

    return respdu;
}

PDU *MySocket::HandleFlushFriends(PDU *pdu)
{
    qDebug() << "Flush Friends";
    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return nullptr; // 数据库初始化失败
    }

    char name[64] = {'\0'};
    memcpy(name, pdu->caData, 64);
    qDebug() << "Flush Friends: " << name;
    QStringList friends = MyDataBase::getInstance().FlushFriends(name, connectionName);
    //qDebug() << "Flush Friends: " << friends.size();
    PDU* respdu = mkPDU(friends.size() * 64);

    respdu->uiMsgType = ENUM_MSG_TYPE_FLUSH_FRIENDS_RESPOND;

    for (int i = 0; i < friends.size(); i += 2) // 每对添加一个名称和在线状态
    {
        // 确保只拷贝最多64字节
        QString friendName = friends[i];
        QString onlineStatus = friends[i + 1];

        // 将好友名字和在线状态合并
        QString combinedInfo = QString("%1|%2").arg(friendName).arg(onlineStatus);

        qDebug() << "Flush friend: " << combinedInfo;

        // 检查合并后的字符串长度是否超过64字节
        if (combinedInfo.size() > 64) {
            combinedInfo = combinedInfo.left(64); // 截断到64字节
        }

        // 拷贝到caMsg中
        memcpy(respdu->caMsg + (i / 2) * 64, combinedInfo.toStdString().c_str(), combinedInfo.size());
        //qDebug() << "Search user: " << combinedInfo;
    }

    return respdu;
}

PDU *MySocket::HandleDeleteFriend(PDU *pdu)
{
    qDebug() << "Delete Friends";
    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return nullptr; // 数据库初始化失败
    }

    char username[64] = {'\0'};
    char friendname[64] = {'\0'};
    memcpy(username, pdu->caData, 64);
    memcpy(friendname, pdu->caData + 64, 64);
    qDebug() << "Delete Friends: " << username << " " << friendname;
    bool success = MyDataBase::getInstance().DeleteFriend(username, friendname, connectionName);
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUM_MSG_TYPE_DELETE_FRIENDS_RESPOND;
    if(success)
    {
        strcpy(respdu->caData, DELETE_FRIEND_OK);
    }
    else
    {
        strcpy(respdu->caData, DELETE_FRIEND_FAIL);
    }
    return respdu;
}

void MySocket::HandleSendMessage(PDU *pdu)
{
    char Msg[pdu->uiMsgLen] = {'\0'};
    char name[64] = {'\0'};
    memcpy(name,pdu->caData,64);
    memcpy(Msg,pdu->caMsg,pdu->uiMsgLen);

    qDebug() << "Send Message: " << name << " " << Msg;

    // this->ForwordMsg("all", pdu);
    //emit forwardMsg("all",pdu);
    MyServer::getInstance().ForWardMsg("all",pdu);

}

void MySocket::HandlePrivateChat(PDU *pdu)
{
    QString connectionName = QString("Connection-%1").arg((quintptr)QThread::currentThreadId());
    if (!MyDataBase::getInstance().initDB(connectionName)) {
        return; // 数据库初始化失败
    }
    char chatForUser[64] = {'\0'};//聊天对象
    char myname[64] = {'\0'};//自己
    memcpy(chatForUser,pdu->caData,64);
    memcpy(myname,pdu->caData+64,64);

    qDebug() << "Private Chat: " << chatForUser << " " << myname;

    bool isOnline = MyDataBase::getInstance().isOnline(chatForUser,connectionName);
    if(isOnline)
    {
        MyServer::getInstance().ForWardMsg(chatForUser,pdu);
    }
}

PDU *MySocket::HandleMkdir(PDU *pdu)
{
    char DirName[64] = {'\0'};
    char CurPath[pdu->uiMsgLen] = {'\0'};
    memcpy(DirName,pdu->caData,64);
    memcpy(CurPath,pdu->caMsg,pdu->uiMsgLen);

    qDebug() << "Mkdir: " << CurPath << " " << DirName;

    QString Mkdir = QString("%1/%2").arg(CurPath).arg(DirName);
    QDir dir;
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUM_MSG_TYPE_MKDIR_RESPOND;
    if(dir.exists(CurPath))
    {
        if(dir.mkdir(Mkdir))
        {
            strcpy(respdu->caData, MKDIR_OK);
        }
        else
        {
            strcpy(respdu->caData, MKDIR_FAIL);
        }
    }
    else
    {
        strcpy(respdu->caData, MKDIR_FAIL);
    }

    return respdu;
}

PDU *MySocket::HandleLS(PDU *pdu)
{
    char CurPath[pdu->uiMsgLen] = {'\0'};
    memcpy(CurPath,pdu->caMsg,pdu->uiMsgLen);

    qDebug() << "LS: " << CurPath;

    QDir dir;
    PDU* respdu = NULL;
    if(!dir.exists(CurPath))
    {
        respdu = mkPDU(0);
        strncpy(respdu->caData,PATH_NOT_EXIST,64);
    }else
    {
        dir.setPath(CurPath);
        QFileInfoList list = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
        int fileNum = list.size();
        respdu = mkPDU(sizeof(FileInfo) * fileNum);
        FileInfo *fileInfo = NULL;//(FileInfo*)respdu->caMsg;

        for(int i = 0;i<fileNum;i++)
        {
            fileInfo = (FileInfo*)(respdu->caMsg) + i;//每次都要重新赋值
            memcpy(fileInfo->caName,list[i].fileName().toStdString().c_str(),list[i].fileName().size());
            fileInfo->bIsDir = list[i].isDir();
            fileInfo->uiSize = list[i].size();
            QDateTime dtLastTime = list[i].lastModified(); // 获取文件最后修改时间
            QString strLastTime = dtLastTime.toString("yyyy/MM/dd hh:mm::ss");
            memcpy(fileInfo->caTime, strLastTime.toStdString().c_str(), strLastTime.size());
            qDebug() << "LS: " << fileInfo->caName << " " << fileInfo->bIsDir << " " << fileInfo->uiSize << " " << strLastTime;
        }
    }
    respdu->uiMsgType = ENUM_MSG_TYPE_LS_RESPOND;
    return respdu;
}

PDU *MySocket::HandleUpload(PDU *pdu, TransFile *transFile)
{

    char fileName[64] = {'\0'};
    char filePath[pdu->uiMsgLen] = {'\0'};
    char userName[64] = {'\0'};
    qint64 fileSize = 0;
    //QString UserName = QString(userName);
    //UploadUserName.push_back(UserName);
    memcpy(filePath,pdu->caMsg,pdu->uiMsgLen);
    sscanf(pdu->caData, "%s %lld",fileName, &fileSize);
    memcpy(userName,pdu->caData+64,64);
    QString strFilePath = QString("%1/%2").arg(filePath).arg(fileName); // 文件路径
    qDebug() << "上传文件路径：" << strFilePath;

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUM_MSG_TYPE_UPLOAD_RESPOND;

    transFile->file.setFileName(strFilePath);


    if(transFile->file.open(QIODevice::WriteOnly)) // 以只写的方式打开文件，文件如果不存在会自动创建
    {
        qDebug() << "打开文件成功";
        transFile->bTransform = true; // 正在上传文件状态
        transFile->iTotalSize = fileSize;
        transFile->iReceivedSize = 0;
        memcpy(respdu->caData, UPLOAD_FILE_START, 64);
    }
    else // 打开文件失败
    {
        memcpy(respdu->caData, UPLOAD_FILE_FAIL, 64);
    }
    qDebug() << "上传文件：" << fileName << " " << fileSize;
    return respdu;
}

PDU *MySocket::HandleDeleteFile(PDU *pdu)
{
    char filePath[pdu->uiMsgLen] = {'\0'};
    memcpy(filePath,pdu->caMsg,pdu->uiMsgLen);

    QString strFilePath = QString("%1").arg(filePath); // 文件路径
    qDebug() << "删除文件：" << strFilePath;

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUM_MSG_TYPE_DELETE_FILE_RESPOND;
    if(QFile::remove(strFilePath))
    {
        strcpy(respdu->caData, DELETE_FILE_OK);
    }
    else
    {
        strcpy(respdu->caData, DELETE_FILE_FAIL);
    }
    return respdu;
}

PDU *MySocket::HandleRenameFile(PDU *pdu)
{
    char OldName[64] = {'\0'};
    char NewName[64] = {'\0'};
    char CurPath[pdu->uiMsgLen] = {'\0'};
    memcpy(OldName,pdu->caData,64);
    memcpy(NewName,pdu->caData+64,64);
    memcpy(CurPath,pdu->caMsg,pdu->uiMsgLen);

    QString strOldName = QString("%1/%2").arg(CurPath).arg(OldName); // 文件路径
    QString strNewName = QString("%1/%2").arg(CurPath).arg(NewName); // 文件路径
    qDebug() << "重命名文件：" << strOldName << " " << strNewName;

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUM_MSG_TYPE_RENAME_FILE_RESPOND;
    if(QFile::rename(strOldName,strNewName))
    {
        strcpy(respdu->caData, RENAME_FILE_OK);
    }
    else
    {
        strcpy(respdu->caData, RENAME_FILE_FAIL);
    }
    return respdu;
}

PDU *MySocket::HandleLSShareArea(PDU *pdu)
{
    char CurPath[pdu->uiMsgLen] = {'\0'};
    memcpy(CurPath,pdu->caMsg,pdu->uiMsgLen);

    qDebug() << "LS: " << CurPath;

    QDir dir;
    PDU* respdu = NULL;
    if(!dir.exists(CurPath))
    {
        respdu = mkPDU(0);
        strncpy(respdu->caData,PATH_NOT_EXIST,64);
    }else
    {
        dir.setPath(CurPath);
        QFileInfoList list = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
        int fileNum = list.size();
        respdu = mkPDU(sizeof(FileInfo) * fileNum);
        FileInfo *fileInfo = NULL;//(FileInfo*)respdu->caMsg;

        for(int i = 0;i<fileNum;i++)
        {
            fileInfo = (FileInfo*)(respdu->caMsg) + i;//每次都要重新赋值
            memcpy(fileInfo->caName,list[i].fileName().toStdString().c_str(),list[i].fileName().size());
            fileInfo->bIsDir = list[i].isDir();
            fileInfo->uiSize = list[i].size();
            QDateTime dtLastTime = list[i].lastModified(); // 获取文件最后修改时间
            QString strLastTime = dtLastTime.toString("yyyy/MM/dd hh:mm::ss");
            memcpy(fileInfo->caTime, strLastTime.toStdString().c_str(), strLastTime.size());
            qDebug() << "LS: " << fileInfo->caName << " " << fileInfo->bIsDir << " " << fileInfo->uiSize << " " << strLastTime;
        }
    }
    respdu->uiMsgType = ENUM_MSG_TYPE_LS_SHAREAREA_RESPOND;
    return respdu;
}

// 实现 HandleDownload 方法
void MySocket::HandleDownload(PDU *pdu)
{
    char fileName[64] = {'\0'};
    char filePath[pdu->uiMsgLen] = {'\0'};
    char tip[64] = {'\0'};
    memcpy(filePath, pdu->caMsg, pdu->uiMsgLen);
    memcpy(fileName, pdu->caData, 64);
    memcpy(tip,pdu->caData+64,64);
    QString Tip = QString(tip);
    QString strFilePath = QString("%1/%2").arg(filePath).arg(fileName); // 文件路径
    qDebug() << "下载文件路径：" << strFilePath;

    // 通过信号将下载请求发送给 FileThread
    // 直接发送下载请求信号
    QMetaObject::invokeMethod(fileThread, "handleDownload", Qt::QueuedConnection,
                              Q_ARG(QString, filePath),
                              Q_ARG(QString, fileName),
                              Q_ARG(QString,  Tip));
}
// 下载响应槽
void MySocket::onDownloadRespond(PDU* pdu)
{
    sendMessage(pdu);
}

// 文件数据准备好槽
void MySocket::onFileDataReady(PDU* pdu)
{
    sendMessage(pdu);
}



