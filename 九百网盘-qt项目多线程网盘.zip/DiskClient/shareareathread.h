#ifndef SHAREAREATHREAD_H
#define SHAREAREATHREAD_H

#include <QObject>
#include "diskclient.h"

class ShareAreaThread : public QObject
{
    Q_OBJECT
public:
    explicit ShareAreaThread(QObject *parent = nullptr);
    void handleFlushFilesRequest(const QString &currentPath);
    void handleDownloadRequest(const QString &DownPath,const QString &currentPath,const QString &fileName);
public slots:
    void downstart(qint64 fileSize);
    Q_INVOKABLE void DownloadingFile(QByteArray caData);
signals:
private:
    TransFile* m_transFile;
};

#endif // SHAREAREATHREAD_H
