#include "diskclient.h"
#include "onlineusers.h"
#include "ui_onlineusers.h"

OnlineUsers::OnlineUsers(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::OnlineUsers)
{
    ui->setupUi(this);
    this->setLayout(ui->verticalLayout_2);
}

OnlineUsers &OnlineUsers::getInstance()
{
    static OnlineUsers instance;
    return instance;
}

void OnlineUsers::showOnlineFriends(QStringList friendslist)
{
    //qDebug() << this->isVisible();
    // 清空现有项
    ui->listWidget->clear();

    // 添加在线好友数量信息
    ui->listWidget->addItem("总共：" + QString::number(friendslist.size()) + " 在线用户");

    // 打印每个用户的详细信息
    for (const QString &friendName : friendslist)
    {
        qDebug() << "好友名：" << friendName;
        ui->listWidget->addItem(friendName);
    }

    // 确保更新
    ui->listWidget->update();

}

OnlineUsers::~OnlineUsers()
{
    delete ui;
}

void OnlineUsers::on_pushButton_clicked()
{
    QListWidgetItem *item = ui->listWidget->currentItem();
    if (item == NULL) {
        qDebug() << "No friend selected.";
        return;
    }
    QString friendName = item->text();
    qDebug() << "Selected friend: " << friendName;
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUM_MSG_TYPE_ADD_FRIENDS_REQUEST;
    QString name = DiskClient::getInstance().getName();
    memcpy(pdu->caData,name.toStdString().c_str(),64);

    memcpy(pdu->caData+64,friendName.toStdString().c_str(),64);
    DiskClient::getInstance().SendMessage(pdu);
    free(pdu);
    pdu = NULL;
}

