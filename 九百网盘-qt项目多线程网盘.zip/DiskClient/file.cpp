#include "file.h"
#include "ui_file.h"
#include "filethread.h"
#include <QFileDialog>
#include <QInputDialog>
#include <QMessageBox>
#include <QProgressBar>
#include <QThread>
#include "operator.h"
File::File(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::File)
    , thread(new QThread(this))
    , fileThread(new FileThread())
{
    ui->setupUi(this);
    this->setLayout(ui->verticalLayout);

    // 将 FileThread 移动到 QThread
    // fileThread->setParent(thread);
    fileThread->moveToThread(thread);

    // 连接信号和槽
    connect(this, &File::mkdirRequested, fileThread, &FileThread::handleMkdirRequest);//创建文件夹
    connect(this, &File::flushFilesRequested, fileThread, &FileThread::handleFlushFilesRequest);//刷新文件列表
    connect(this, &File::uploadRequested, fileThread, &FileThread::handleUploadRequest);//上传文件
    connect(this,&File::UploadFileBeginning,fileThread,&FileThread::UploadFileBeginning);//上传文件开始
    connect(this,&File::deleteRequested,fileThread,&FileThread::handleDeleteRequest);//删除文件
    connect(this,&File::renameRequested,fileThread,&FileThread::handleRenameRequest);//重命名文件
    connect(this,&File::downloadRequested,fileThread,&FileThread::handleDownloadRequest);//下载文件
    connect(this,&File::downstart,fileThread,&FileThread::downstart);//下载文件开始

    // 连接 FileThread 发送的响应信号到 File 类的槽
    connect(fileThread, &FileThread::sendFlushFilesResponse, this, &File::FlushFiles);//刷新文件列表
    connect(ui->listWidgetFile, &QListWidget::itemDoubleClicked, this, &File::IntoDir);//双击进入文件夹

    // 启动线程
    thread->start();

    //进度条
    m_pDialog = new QDialog();
    m_pDialog->setWindowTitle("文件下载进度");
    m_pDialog->setFixedSize(300,100);
    m_pProgressBar = new QProgressBar(m_pDialog);
    m_pVLayout = new QVBoxLayout(m_pDialog);
    m_pVLayout->addWidget(m_pProgressBar);
    m_pDialog->setLayout(m_pVLayout);
    m_pDialog->hide();

}

File::~File()
{
    thread->quit();
    thread->wait();
    delete ui;
}
// 辅助函数：过滤掉不需要的字符
QString File::filterNonPrintable(const QString &input) {
    QString filtered;
    for (QChar c : input) {
        // 保留 ASCII >= 32，或者是 '\n' 或 '\t'
        if (c.unicode() >= 32 || c == '\n' || c == '\t') {
            filtered.append(c);
        }
    }
    return filtered;
}

void File::startDownload(PDU* pdu)//开始下载文件
{
    //m_transFile->bTransform = true;
    char fileName[64] = {'\0'};
    qint64 fileSize = 0;
    sscanf(pdu->caMsg,"%s %lld",fileName,&fileSize);
    //QString downFilePath = QString("%1/%2").arg(m_currentPath).arg(fileName);

    emit downstart(fileSize);
    //m_pProgressBar->setMaximum(fileSize);
    FileMaxSize = fileSize;
    m_pProgressBar->setRange(0,fileSize);
    m_pDialog->show();

}

void File::FlushFiles(PDU *pdu)//刷新文件列表
{
    if(pdu == NULL)
    {
        return;
    }
    qDebug()<<"正在刷新文件列表...";
    uint fileNums = pdu->uiMsgLen / sizeof(FileInfo);
    FileInfo* fileInfos = NULL;
    QListWidgetItem* item = NULL;
    ui->listWidgetFile->clear();

    for(uint i=0;i<fileNums;i++)
    {
        fileInfos = (FileInfo*)(pdu->caMsg) + i;
        item = new QListWidgetItem;
        if(fileInfos->bIsDir)
        {
            item->setIcon(QIcon(QPixmap(":/image/dir.png")));
        }
        else
        {
            item->setIcon(QIcon(QPixmap(":/image/file.png")));
        }
        QString caName = QString::fromLocal8Bit(fileInfos->caName);
        caName = filterNonPrintable(caName);
        item->setText(QString("%1\t%2\t%3").arg(caName).arg(fileInfos->uiSize).arg(fileInfos->caTime));
        ui->listWidgetFile->addItem(item);
    }
}

void File::PressFlushFiles()//按下刷新按钮
{
    on_btnFlushFiles_clicked();
}

void File::startUpload()//开始上传文件
{
    QFile file(FilePath);

    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "文件打开失败";
        return;
    }

    qDebug() << "开始上传文件...";

    qint64 totalSize = file.size();
    qint64 totalBytesTransferred = 0;

    // 创建一个弹窗
    QDialog progressDialog;
    progressDialog.setWindowTitle("文件上传进度");

    // 创建进度条
    QProgressBar *progressBar = new QProgressBar(&progressDialog);
    progressBar->setRange(0, totalSize);

    // 设置布局
    QVBoxLayout *layout = new QVBoxLayout(&progressDialog);
    layout->addWidget(progressBar);
    progressDialog.setLayout(layout);
    progressDialog.resize(300, 100);

    // 显示进度对话框
    progressDialog.show();

    while (totalSize > totalBytesTransferred) {
        QByteArray buf = file.read(4096);
        if (buf.isEmpty()) break; // 文件读取结束

        qint64 bufSize = buf.size();
        qDebug() << "读取" << bufSize << "字节";
        if (bufSize > 0) {
            totalBytesTransferred += bufSize;

            QMetaObject::invokeMethod(fileThread, "UploadFileBeginning", Qt::QueuedConnection,
                                      Q_ARG(QByteArray, buf), Q_ARG(qint64, bufSize));

            progressBar->setValue(totalBytesTransferred);

            // qDebug() << "已读取" << bufSize << "字节";
            qDebug() << "发送的总大小" << totalBytesTransferred;
        }

        qApp->processEvents(); // 处理事件
    }

    qDebug() << "文件上传完毕";
    file.close();
    FilePath.clear();
    progressBar->setValue(totalSize);
    progressDialog.close();

}

void File::IntoDir()//进入文件夹
{
    QListWidgetItem* item = ui->listWidgetFile->currentItem();
    if(item == NULL)
    {
        return;
    }
    QString DirName = item->text().split("\t")[0];
    //qDebug() << "进入目录：" << DirName;
    m_currentPath = DiskClient::getInstance().getCurrentPath();
    m_currentPath += "/";
    m_currentPath += DirName;
    DiskClient::getInstance().setCurrentPath(m_currentPath);
    emit flushFilesRequested(m_currentPath);

}

void File::startReceivingFile(QByteArray caData)//开始接收文件
{
    qDebug()<<"开始接收文件...";
    QMetaObject::invokeMethod(fileThread, "DownloadingFile", Qt::QueuedConnection,
                              Q_ARG(QByteArray, caData));

    qint64 Size = caData.size();
    m_pProgressBar->setValue(Size + m_pProgressBar->value());
    if(Size < 4096)
    {
        qDebug()<<"文件接收完毕";
        m_pDialog->hide();
    }
}

void File::on_btnmkdir_clicked()//新建文件夹
{
    qDebug() << "新建文件夹";
    QString dirName = QInputDialog::getText(this, "新建文件夹", "请输入文件夹名称");
    if (dirName.isEmpty())
    {
        return;
    }
    qDebug() << "新建文件夹：" << dirName;
    m_currentPath = DiskClient::getInstance().getCurrentPath();// 获取当前路径

    // 发出信号请求在 FileThread 中处理
    emit mkdirRequested(m_currentPath, dirName);
}

void File::on_btnupload_clicked()//上传
{
    // 弹出文件选择对话框，选择要上传的文件
    FilePath = QFileDialog::getOpenFileName(this, "选择文件", QStandardPaths::writableLocation(QStandardPaths::HomeLocation), "All files (*.*)");
    if (FilePath.isEmpty())
    {
        return; // 如果没有选择文件，直接返回
    }

    qDebug() << "上传文件：" << FilePath;
    QFile file(FilePath);
    qint64 fileSize = file.size(); // 获得文件大小
    // 弹出一个对话框，让用户选择上传路径
    QMessageBox msgBox;
    msgBox.setWindowTitle("选择上传路径");
    msgBox.setText("请选择上传到哪个路径：");
    QPushButton *curPathButton = msgBox.addButton("用户路径", QMessageBox::ActionRole);
    QPushButton *sharePathButton = msgBox.addButton("共享路径", QMessageBox::ActionRole);
    msgBox.setDefaultButton(curPathButton); // 设置默认选择按钮
    msgBox.exec(); // 显示对话框，等待用户选择

    // 根据用户的选择执行不同的操作
    if (msgBox.clickedButton() == curPathButton)
    {
        qDebug() << "选择上传到当前路径";
        m_currentPath = DiskClient::getInstance().getCurrentPath(); // 获取当前路径
    }
    else if (msgBox.clickedButton() == sharePathButton)
    {
        qDebug() << "选择上传到共享路径";
        m_currentPath = DiskClient::getInstance().getSharePath(); // 获取共享路径
    }
    else
    {
        qDebug() << "取消上传";
        return; // 如果用户取消，直接返回
    }
    qDebug() << "上传路径：" << m_currentPath;
    QString userName = DiskClient::getInstance().getName();//获取用户名
    emit uploadRequested(m_currentPath,FilePath,fileSize,userName);
}

void File::on_btnFlushFiles_clicked()//刷新
{
    qDebug() << "刷新文件列表";
    m_currentPath = DiskClient::getInstance().getCurrentPath();// 获取当前路径

    // 发出信号请求在 FileThread 中处理
    emit flushFilesRequested(m_currentPath);
}

void File::on_btnBack_clicked()//返回上级目录
{
    //qDebug() << "返回上级目录";
    m_currentPath = DiskClient::getInstance().getCurrentPath();// 获取当前路径
    //qDebug() << "当前路径：" << m_currentPath;
    //qDebug() << "根路径：" << DiskClient::getInstance().getRootPath();
    if(m_currentPath == DiskClient::getInstance().getRootPath())
    {
        qDebug() << "已经是根目录了";
        return;
    }
    int index = m_currentPath.lastIndexOf('/');
    m_currentPath = m_currentPath.left(index);
    DiskClient::getInstance().setCurrentPath(m_currentPath);
    emit flushFilesRequested(m_currentPath);
}

void File::on_btnDelete_clicked()//删除文件
{
    QListWidgetItem* item = ui->listWidgetFile->currentItem();
    if(item == NULL)
    {
        return;
    }
    QString FileName = item->text().split("\t")[0];
    m_currentPath = DiskClient::getInstance().getCurrentPath();
    m_currentPath += "/";
    m_currentPath += FileName;
    qDebug() << "删除文件：" << m_currentPath;
    emit deleteRequested(m_currentPath);
}

void File::on_btnRename_clicked()//重命名
{
    QListWidgetItem* item = ui->listWidgetFile->currentItem();
    if(item == NULL)
    {
        return;
    }
    QString OldName = item->text().split("\t")[0];
    QString NewName = QInputDialog::getText(this, "重命名", "请输入新的文件名");
    if (NewName.isEmpty())
    {
        return;
    }
    m_currentPath = DiskClient::getInstance().getCurrentPath();

    emit renameRequested(m_currentPath , OldName, NewName);
}

void File::on_btnDownload_clicked()//下载
{
    QListWidgetItem* item = ui->listWidgetFile->currentItem();
    if(item == NULL)
    {
        return;
    }

    QString DownFilePath = QFileDialog::getSaveFileName();
    if(DownFilePath.isEmpty())
    {
        return;
    }

    QString FileName = item->text().split("\t")[0];
    m_currentPath = DiskClient::getInstance().getCurrentPath();

    qDebug() << "下载文件：" << m_currentPath<<"/"<<FileName;
    emit downloadRequested(DownFilePath,m_currentPath,FileName);
}

