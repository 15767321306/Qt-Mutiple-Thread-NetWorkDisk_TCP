#include "mysetting.h"
#include "ui_mysetting.h"
#include "operator.h"
MySetting::MySetting(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MySetting)
{
    ui->setupUi(this);
    this->setLayout(ui->verticalLayout_2);
    //主题设置
    ui->backGround->addItem("默认背景");
    ui->backGround->addItem("梦幻紫蓝");
    ui->backGround->addItem("清新蓝色");
    ui->backGround->addItem("热情红色");
    ui->backGround->addItem("森林绿意");
    ui->backGround->addItem("温暖橙色");
    ui->backGround->addItem("宁静夜空");
    ui->backGround->addItem("炫酷黑色");
    ui->backGround->addItem("粉色少女");
    ui->backGround->addItem("高贵金色");
}

MySetting::~MySetting()
{
    delete ui;
}

void MySetting::on_btnSet_clicked()
{

    int index = ui->backGround->currentRow();//
    QMetaObject::invokeMethod(&Operator::getInstance(), "setBackGround",
                              Q_ARG(int,index));
}

