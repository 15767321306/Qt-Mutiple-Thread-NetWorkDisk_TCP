#include "shareareathread.h"

ShareAreaThread::ShareAreaThread(QObject *parent)
    : QObject{parent}
{
    m_transFile = new TransFile();
}

void ShareAreaThread::handleFlushFilesRequest(const QString &currentPath)
{
    //qDebug() << "ShareAreaThread: 处理刷新文件列表请求";
    PDU* pdu = mkPDU(currentPath.size() + 1);
    pdu->uiMsgType = ENUM_MSG_TYPE_LS_SHAREAREA_REQUEST;
    memcpy(pdu->caMsg, currentPath.toStdString().c_str(), currentPath.size() + 1);

    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));

    free(pdu);
    pdu = nullptr;
}

void ShareAreaThread::handleDownloadRequest(const QString &DownPath, const QString &currentPath, const QString &fileName)
{
    if(currentPath.isEmpty())
    {
        return;
    }
    PDU* pdu = mkPDU(currentPath.size() + 1);
    m_transFile->file.setFileName(DownPath);
    pdu->uiMsgType = ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST;
    memcpy(pdu->caData, fileName.toStdString().c_str(),64);
    memcpy(pdu->caData+64,DOWNLOAD_FILE_SHARE,64);//标识下载共享区文件
    memcpy(pdu->caMsg,currentPath.toStdString().c_str(),currentPath.size() + 1);

    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));
    qDebug()<<"共享区发送下载请求";
}

void ShareAreaThread::downstart(qint64 fileSize)
{
    qDebug()<<"共享区下载回应开始";

    if(m_transFile->file.open(QIODevice::WriteOnly))
    {
        m_transFile->bTransform = true;
        m_transFile->iTotalSize = fileSize;
        m_transFile->iReceivedSize = 0;

        QMetaObject::invokeMethod(&DiskClient::getInstance(), "DownloadFile", Qt::QueuedConnection,
                                  Q_ARG(int, 2));
    }
    else
    {
        qDebug()<<"打开文件失败";
    }
}

void ShareAreaThread::DownloadingFile(QByteArray caData)
{
    if(m_transFile->bTransform)
    {
        qDebug()<<"共享区下载开始";
        // 将 QByteArray 的数据写入文件
        if (m_transFile->file.write(caData) == -1) {
            qDebug() << "写入文件失败，错误:" << m_transFile->file.errorString();
            return; // 写入失败，直接返回
        }

        // 更新已接收大小

        m_transFile->iReceivedSize += caData.size();
        qDebug() << "已接收大小:" << m_transFile->iReceivedSize;

        // 调试信息
        qDebug() << "预期接收总大小:" << m_transFile->iTotalSize;

        //emit progressUpdate(m_transFile->iReceivedSize,m_transFile->iTotalSize);
        if(m_transFile->iReceivedSize == m_transFile->iTotalSize) {
            m_transFile->file.close();
            m_transFile->bTransform = false;
            qDebug() << "文件接收完毕";
            QMetaObject::invokeMethod(&DiskClient::getInstance(), "DownloadFile", Qt::QueuedConnection,Q_ARG(int, 0));

        }else if(m_transFile->iReceivedSize > m_transFile->iTotalSize) {
            qDebug() << "接收大小超过预期大小";
            qDebug() << "接收大小:" << m_transFile->iReceivedSize;
            qDebug() << "预期大小:" << m_transFile->iTotalSize;
            QMetaObject::invokeMethod(&DiskClient::getInstance(), "DownloadFile", Qt::QueuedConnection,Q_ARG(int, 0));
        }
    }
}
