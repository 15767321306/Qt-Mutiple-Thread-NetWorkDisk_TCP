#ifndef SHAREFILES_H
#define SHAREFILES_H

#include <QWidget>
#include "protocol.h"
#include "shareareathread.h"
#include <QThread>
#include <QProgressBar>
#include <QStandardPaths>
#include <QVBoxLayout>
#include <QDialog>
namespace Ui {
class ShareFiles;
}

class ShareFiles : public QWidget
{
    Q_OBJECT

public:
    explicit ShareFiles(QWidget *parent = nullptr);
    ~ShareFiles();
    QString filterNonPrintable(const QString &input);
    void FlushShareFiles(PDU* pdu);
    void PressFlushFiles();
    void startDownload(PDU* pdu);
signals:
    void btnFlushFiles_clicked(const QString &sharePath);
    void downloadRequested(const QString &DownPath,const QString &currentPath,const QString &fileName);
    void downstart(qint64 fileSize);
private slots:
    void on_btnFlush_clicked();
    void on_btnDownload_clicked();
public slots:
    void startReceivingFile(QByteArray caData);
private:
    Ui::ShareFiles *ui;
    QThread* thread;
    class ShareAreaThread* ShareThread; // 前向声明
    QString m_currentPath;
private:
    QProgressBar* m_pProgressBar;
    QDialog *m_pDialog;
    QVBoxLayout *m_pVLayout;
    qint64 FileMaxSize;
};

#endif // SHAREFILES_H
