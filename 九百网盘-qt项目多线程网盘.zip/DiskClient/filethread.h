#ifndef FILETHREAD_H
#define FILETHREAD_H

#include <QObject>
#include "diskclient.h"

class FileThread : public QObject
{
    Q_OBJECT
public:
    explicit FileThread(QObject *parent = nullptr);
signals:
    void sendFlushFilesResponse(PDU* pdu);
    void send(PDU* pdu);
    void progressUpdate(qint64 bytesReceived, qint64 bytesTotal);
public slots:
    void handleMkdirRequest(const QString &currentPath, const QString &dirName);
    void handleFlushFilesRequest(const QString &currentPath);
    void handleUploadRequest(const QString &currentPath, const QString &filePath,qint64 fileSize,const QString &userName);
    Q_INVOKABLE void UploadFileBeginning(QByteArray caData, qint64 fileSize);
    void handleDeleteRequest(const QString &currentPath);
    void handleRenameRequest(const QString &currentPath,const QString &OldName, const QString &newName);
    void handleDownloadRequest(const QString &DownloadPath,const QString &currentPath,const QString &fileName);
    void downstart(qint64 fileSize);
    Q_INVOKABLE void DownloadingFile(QByteArray caData);
    // 添加其他处理槽
private:
    TransFile* m_transFile;
};

#endif // FILETHREAD_H
