#ifndef OPERATOR_H
#define OPERATOR_H

#include <QWidget>
#include <QPushButton>
#include "file.h"
#include "frients.h"
#include "onlineusers.h"
#include "sharefiles.h"
#include "mysetting.h"
class Frients;
class File;
class ShareFiles;
class MySetting;
namespace Ui {
class Operator;
}

class Operator : public QWidget
{
    Q_OBJECT

public:
    static Operator& getInstance();
    ~Operator();
    void switchPage();
    Frients * getFriends();
    File* getFileSystem();
    ShareFiles * getShareFiles();
    MySetting * getMySetting();
    //OnlineUsers * getOnlineUsers();
public slots:
    void setBackGround(int type);
private slots:
    void on_btnFile_clicked();

    void on_btnFriend_clicked();

    void on_btnShare_clicked();

    void on_btnMy_clicked();

private:
    Ui::Operator *ui;
    explicit Operator(QWidget *parent = nullptr);
    File *file;
    Frients *friends;
    ShareFiles *shareFiles;
    MySetting *mySetting;
    //OnlineUsers *onlineUsers;
};

#endif // OPERATOR_H
