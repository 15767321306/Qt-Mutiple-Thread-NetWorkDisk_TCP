#include "sharefiles.h"
#include "ui_sharefiles.h"
#include <QDebug>
#include <qfiledialog.h>
ShareFiles::ShareFiles(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ShareFiles)
{
    ui->setupUi(this);
    this->setLayout(ui->verticalLayout);
    thread = new QThread(this);
    ShareThread = new ShareAreaThread();
    ShareThread->moveToThread(thread);
    connect(this,&ShareFiles::btnFlushFiles_clicked,ShareThread,&ShareAreaThread::handleFlushFilesRequest);
    connect(this,&ShareFiles::downloadRequested,ShareThread,&ShareAreaThread::handleDownloadRequest);
    connect(this,&ShareFiles::downstart,ShareThread,&ShareAreaThread::downstart);
    thread->start();

    //进度条
    m_pDialog = new QDialog();
    m_pDialog->setWindowTitle("文件下载进度");
    m_pDialog->setFixedSize(300,100);
    m_pProgressBar = new QProgressBar(m_pDialog);
    m_pVLayout = new QVBoxLayout(m_pDialog);
    m_pVLayout->addWidget(m_pProgressBar);
    m_pDialog->setLayout(m_pVLayout);
    m_pDialog->hide();
}

ShareFiles::~ShareFiles()
{
    thread->quit();
    thread->wait();
    delete ui;
}
QString ShareFiles::filterNonPrintable(const QString &input) {
    QString filtered;
    for (QChar c : input) {
        // 保留 ASCII >= 32，或者是 '\n' 或 '\t'
        if (c.unicode() >= 32 || c == '\n' || c == '\t') {
            filtered.append(c);
        }
    }
    return filtered;
}

void ShareFiles::FlushShareFiles(PDU *pdu)
{
    if(pdu == NULL)
    {
        return;
    }
    qDebug()<<"正在刷新文件列表...";
    uint fileNums = pdu->uiMsgLen / sizeof(FileInfo);
    FileInfo* fileInfos = NULL;
    QListWidgetItem* item = NULL;
    ui->listWidget->clear();

    for(uint i=0;i<fileNums;i++)
    {
        fileInfos = (FileInfo*)(pdu->caMsg) + i;
        item = new QListWidgetItem;
        if(fileInfos->bIsDir)
        {
            item->setIcon(QIcon(QPixmap(":/image/dir.png")));
        }
        else
        {
            item->setIcon(QIcon(QPixmap(":/image/file.png")));
        }
        QString caName = QString::fromLocal8Bit(fileInfos->caName);
        caName = filterNonPrintable(caName);
        item->setText(QString("%1\t%2\t%3").arg(caName).arg(fileInfos->uiSize).arg(fileInfos->caTime));
        ui->listWidget->addItem(item);
    }
}

void ShareFiles::PressFlushFiles()
{
    on_btnFlush_clicked();
}

void ShareFiles::startDownload(PDU *pdu)
{
    //m_transFile->bTransform = true;
    char fileName[64] = {'\0'};
    qint64 fileSize = 0;
    sscanf(pdu->caMsg,"%s %lld",fileName,&fileSize);
    //QString downFilePath = QString("%1/%2").arg(m_currentPath).arg(fileName);

    emit downstart(fileSize);
    //m_pProgressBar->setMaximum(fileSize);
    FileMaxSize = fileSize;
    m_pProgressBar->setRange(0,fileSize);
    m_pDialog->show();
}

void ShareFiles::on_btnFlush_clicked()
{
    qDebug() << "刷新文件列表";
    QString SharePath = DiskClient::getInstance().getSharePath();
    emit btnFlushFiles_clicked(SharePath);
}

void ShareFiles::on_btnDownload_clicked()
{
    QListWidgetItem* item = ui->listWidget->currentItem();
    if(item == NULL)
    {
        return;
    }

    QString DownFilePath = QFileDialog::getSaveFileName();
    if(DownFilePath.isEmpty())
    {
        return;
    }

    QString FileName = item->text().split("\t")[0];
    m_currentPath = DiskClient::getInstance().getSharePath(); // 获取共享目录路径

    qDebug() << "下载共享区文件：" << m_currentPath<<"/"<<FileName;
    emit downloadRequested(DownFilePath,m_currentPath,FileName);
}

void ShareFiles::startReceivingFile(QByteArray caData)
{
    qDebug()<<"共享区开始接收文件...";
    QMetaObject::invokeMethod(ShareThread, "DownloadingFile", Qt::QueuedConnection,
                              Q_ARG(QByteArray, caData));

    qint64 Size = caData.size();
    m_pProgressBar->setValue(Size + m_pProgressBar->value());
    if(Size < 4096)
    {
        qDebug()<<"共享区文件接收完毕";
        m_pDialog->hide();
    }
}

