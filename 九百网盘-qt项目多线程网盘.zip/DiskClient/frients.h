#ifndef FRIENTS_H
#define FRIENTS_H

#include <QWidget>
#include "protocol.h"
#include "diskclient.h"
namespace Ui {
class Frients;
}

class Frients : public QWidget
{
    Q_OBJECT

public:
    static Frients& getInstance();
    explicit Frients(QWidget *parent = nullptr);
    ~Frients();

    void SetName(QString name);

    void showSearchUsers(QStringList users);

    void FlushFriends(QStringList friendslist);

    void PressedFlushFriend();

    void WriteMsgIntoTextEdit(const QString msg);

    void showMsgPDU(PDU *pdu);


private slots:
    void on_btnShowOnline_clicked();

    void on_btnFlushFriends_clicked();

    void on_btnPrivateChat_clicked();

    void on_btnSendmsg_clicked();

    void on_btnDeleteFriends_clicked();

    void on_btnSearchPerson_clicked();

private:
    Ui::Frients *ui;

};

#endif // FRIENTS_H
