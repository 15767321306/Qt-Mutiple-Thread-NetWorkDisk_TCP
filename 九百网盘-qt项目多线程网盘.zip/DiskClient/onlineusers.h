#ifndef ONLINEUSERS_H
#define ONLINEUSERS_H

#include <QWidget>
#include <QListWidgetItem>
#include "protocol.h"
namespace Ui {
class OnlineUsers;
}

class OnlineUsers : public QWidget
{
    Q_OBJECT

public:
    explicit OnlineUsers(QWidget *parent = nullptr);
    ~OnlineUsers();
    static OnlineUsers &getInstance();
    void showOnlineFriends(QStringList friendslist);
private slots:
    void on_pushButton_clicked();

private:
    Ui::OnlineUsers *ui;
};

#endif // ONLINEUSERS_H
