#ifndef PRIVATECHAT_H
#define PRIVATECHAT_H

#include <QWidget>
#include "diskclient.h"
#include "protocol.h"
namespace Ui {
class PrivateChat;
}

class PrivateChat : public QWidget
{
    Q_OBJECT

public:
    explicit PrivateChat(QWidget *parent = nullptr);
    ~PrivateChat();
    static PrivateChat &getIntance();
    void showPrivateWindow(PDU* pdu);
    void startChat(QString name);
    QString filterNonPrintable(const QString &input);
private slots:
    void on_btnSend_clicked();

private:
    Ui::PrivateChat *ui;
};

#endif // PRIVATECHAT_H
