#ifndef DISKCLIENT_H
#define DISKCLIENT_H

#include <QWidget>
#include <QTcpSocket>
#include <QFile>
#include "protocol.h"
#include <QTimer>
#include "operator.h"
#include "onlineusers.h"
#include "privatechat.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class DiskClient;
}
QT_END_NAMESPACE

class DiskClient : public QWidget
{
    Q_OBJECT

public:
    static DiskClient& getInstance();
    ~DiskClient();
    QTcpSocket* getSocket();
    void connectToServer(const QString &ip, quint16 port);
    Q_INVOKABLE void SendMessage(PDU* pdu); // 发送消息 QINVOKABLE表示 Qt 的元对象系统中注册为可调用的函数
    void loadConfig();
    void ShowAutoCloseMessageBox(const QString &title, const QString &text, int timeout);
    void logout();
    Q_INVOKABLE void socketSendData(PDU* pdu);
public:
    QString getName() const;
    void setName(const QString &name);

    QString getPwd() const;
    void setPwd(const QString &pwd);

    QString getRootPath() const;
    void setRootPath(const QString &rootpath);

    QString getCurrentPath() const;
    void setCurrentPath(const QString &currentPath);

    QString getSharePath() const;
    void setSharePath(const QString &sharePath);

    Q_INVOKABLE void DownloadFile(int isDownload);
public slots:
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onError(QAbstractSocket::SocketError socketError);
    void DealPDUs(PDU *pdu);
private slots:
    void on_btnLogin_clicked();

    void on_btnRegister_clicked();
signals:
    void HandlePDU(PDU *pdu);
private:
    DiskClient(QWidget *parent = nullptr);
    Ui::DiskClient *ui;
    QTcpSocket *m_socket;
    QString ip;
    quint16 port;

    QString m_name;
    QString m_pwd;

    QString configPath;
    QString m_RootPath;
    QString m_CurrentPath;
    QString m_SharePath;

    QByteArray m_buffer;
    int m_download;
};
#endif // DISKCLIENT_H
