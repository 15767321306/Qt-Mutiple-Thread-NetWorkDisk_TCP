#ifndef MYSETTING_H
#define MYSETTING_H

#include <QWidget>

namespace Ui {
class MySetting;
}

class MySetting : public QWidget
{
    Q_OBJECT

public:
    explicit MySetting(QWidget *parent = nullptr);
    ~MySetting();

private slots:
    void on_btnSet_clicked();

private:
    Ui::MySetting *ui;
};

#endif // MYSETTING_H
