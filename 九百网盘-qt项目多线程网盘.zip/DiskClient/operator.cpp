#include "operator.h"
#include "ui_operator.h"
#include <QDebug>

Operator::Operator(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Operator)
{
    ui->setupUi(this);
    this->setLayout(ui->horizontalLayout);
    file = new File();
    ui->stackedWidget->addWidget(file);
    friends = new Frients();
    ui->stackedWidget->addWidget(friends);
    shareFiles = new ShareFiles();
    ui->stackedWidget->addWidget(shareFiles);
    mySetting = new MySetting();
    ui->stackedWidget->addWidget(mySetting);
}

Operator &Operator::getInstance()
{
    static Operator instance;
    return instance;
}

Operator::~Operator()
{
    delete ui;
}

void Operator::switchPage()
{
    QPushButton *button = qobject_cast<QPushButton *>(sender());
    if (button == ui->btnFile) {
        ui->stackedWidget->setCurrentIndex(0);
    } else if (button == ui->btnFriend) {
        ui->stackedWidget->setCurrentIndex(1);
        qDebug() << "Switching to Friends page, isVisible:" << friends->isVisible(); // 添加调试信息
    } else if (button == ui->btnShare) {
        ui->stackedWidget->setCurrentIndex(2);
    } else if (button == ui->btnMy) {
        ui->stackedWidget->setCurrentIndex(3);
    }
}

Frients *Operator::getFriends()
{
    return friends;
}

File *Operator::getFileSystem()
{
    return file;
}

ShareFiles *Operator::getShareFiles()
{
    return shareFiles;
}

void Operator::setBackGround(int type)
{
    // qDebug() << "Setting background to type:" << type;

    QString styleSheet;
    switch (type) {
    case 0:
        // 默认样式
        styleSheet = "QWidget { background-color:rgb(223, 223, 223); }"  // 默认背景
                     "QListWidget { background-color: rgba(255, 255, 255, 200); }"
                     "QPushButton { background-color: rgb(58, 171, 223); border-radius: 8px; }"
                     "QPushButton:hover { background-color: rgb(140, 228, 255); }"
                     "QPushButton:pressed { background-color: rgb(54, 132, 181); }"
                     "QLineEdit { background-color: #ffffff; border: 1px solid #cccccc; }"
                     "QTextEdit { background-color: #ffffff; border: 1px solid #cccccc; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 1:
        // 主题 1: 渐变色背景
        styleSheet = "QWidget { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #6a11cb, stop:1 #2575fc); }"
                     "QListWidget { background-color: rgba(255, 255, 255, 200); }"
                     "QPushButton { background-color: #6a11cb; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #4a0c99; }"
                     "QPushButton:pressed { background-color: #3c0a80; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #4a0c99; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #4a0c99; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 2:
        // 主题 2: 渐变色背景
        styleSheet = "QWidget { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00c6ff, stop:1 #0072ff); }"
                     "QListWidget { background-color: rgba(255, 255, 255, 200); }"
                     "QPushButton { background-color: #00c6ff; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #0099cc; }"
                     "QPushButton:pressed { background-color: #0072a8; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #00c6ff; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #00c6ff; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 3:
        // 主题 3: 渐变色背景
        styleSheet = "QWidget { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #ff416c, stop:1 #ff4b2b); }"
                     "QListWidget { background-color: rgba(255, 255, 255, 200); }"
                     "QPushButton { background-color: #ff416c; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #c32a5b; }"
                     "QPushButton:pressed { background-color: #a0264d; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #ff416c; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #ff416c; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 4:
        // 主题 4: 森林绿色
        styleSheet = "QWidget { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #43cea2, stop:1 #185a9d); }"
                     "QListWidget { background-color: rgba(240, 255, 240, 200); }"
                     "QPushButton { background-color: #43cea2; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #2c8e73; }"
                     "QPushButton:pressed { background-color: #226854; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #43cea2; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #43cea2; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 5:
        // 主题 5: 暖橙色
        styleSheet = "QWidget { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #ffaf7b, stop:1 #d76d77); }"
                     "QListWidget { background-color: rgba(255, 245, 230, 200); }"
                     "QPushButton { background-color: #ffaf7b; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #d76d77; }"
                     "QPushButton:pressed { background-color: #b45354; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #ffaf7b; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #ffaf7b; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 6:
        // 主题 6: 夜空蓝
        styleSheet = "QWidget { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2c3e50, stop:1 #4ca1af); }"
                     "QListWidget { background-color: rgba(230, 240, 255, 200); }"
                     "QPushButton { background-color: #2c3e50; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #34495e; }"
                     "QPushButton:pressed { background-color: #22313f; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #2c3e50; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #2c3e50; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 7:
        // 主题 7: 炫酷黑色
        styleSheet = "QWidget { background-color: black; }"
                     "QListWidget { background-color: rgba(255, 255, 255, 200); }"
                     "QPushButton { background-color: #1abc9c; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #16a085; }"
                     "QPushButton:pressed { background-color: #1e8f77; }"
                     "QLineEdit { background-color: #333; border: 1px solid #1abc9c; }"
                     "QTextEdit { background-color: #333; border: 1px solid #1abc9c; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 8:
        // 主题 8: 粉色少女
        styleSheet = "QWidget { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #ff6f61, stop:1 #de1f6d); }"
                     "QListWidget { background-color: rgba(255, 255, 255, 200); }"
                     "QPushButton { background-color: #ff6f61; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #d45d59; }"
                     "QPushButton:pressed { background-color: #b94c52; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #ff6f61; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #ff6f61; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    case 9:
        // 主题 9: 高贵金色
        styleSheet = "QWidget { background-color: #f3e5ab; }"
                     "QListWidget { background-color: rgba(255, 255, 255, 200); }"
                     "QPushButton { background-color: #d4af37; color: white; border-radius: 5px; }"
                     "QPushButton:hover { background-color: #b89b28; }"
                     "QPushButton:pressed { background-color: #9e7f20; }"
                     "QLineEdit { background-color: #fff; border: 1px solid #d4af37; }"
                     "QTextEdit { background-color: #fff; border: 1px solid #d4af37; }"
                     "QLabel { background: none; }";  // QLabel背景透明
        break;
    default:
        break;
    }

    this->setStyleSheet(styleSheet);
}



// MySetting *Operator::getMySetting()
// {
//     return mySetting;
// }

void Operator::on_btnFile_clicked()
{
    switchPage();
}


void Operator::on_btnFriend_clicked()
{
    switchPage();
}


void Operator::on_btnShare_clicked()
{
    switchPage();
}


void Operator::on_btnMy_clicked()
{
    switchPage();
}

