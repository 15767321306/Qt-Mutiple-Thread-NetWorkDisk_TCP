#include "privatechat.h"
#include "ui_privatechat.h"

PrivateChat::PrivateChat(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PrivateChat)
{
    ui->setupUi(this);
    this->setLayout(ui->verticalLayout);
}

PrivateChat &PrivateChat::getIntance()
{
    static PrivateChat instance;
    return instance;
}
// 辅助函数：过滤掉不需要的字符
QString PrivateChat::filterNonPrintable(const QString &input) {
    QString filtered;
    for (QChar c : input) {
        // 保留 ASCII >= 32，或者是 '\n' 或 '\t'
        if (c.unicode() >= 32 || c == '\n' || c == '\t') {
            filtered.append(c);
        }
    }
    return filtered;
}

void PrivateChat::showPrivateWindow(PDU *pdu)
{
    char name[64] = {'\0'};
    memcpy(name,pdu->caData+64,64);
    if(name == DiskClient::getInstance().getName())//不显示自己的私聊窗口
    {
        return;
    }
    ui->label_name->setText(QString(name)+ "-正在和你聊天");
    char msg[pdu->uiMsgLen] = {'\0'};
    memcpy(msg,pdu->caMsg,pdu->uiMsgLen);
    QString message = QString::fromLocal8Bit(msg,pdu->uiMsgLen).trimmed();
    ui->textEdit_showMSg->append(QString(name) + ":" + filterNonPrintable(message));
    this->show();
}

void PrivateChat::startChat(QString name)
{
    ui->label_name->setText(name + "-正在和你聊天");
    this->show();
}

PrivateChat::~PrivateChat()
{
    delete ui;
}

void PrivateChat::on_btnSend_clicked()
{
    // 获取用户输入的消息
    QString msg = ui->lineEdit_Msg->text();
    if (msg.isEmpty())
    {
        DiskClient::getInstance().ShowAutoCloseMessageBox("私聊请求","消息不能为空",2000);
        return;
    }

    // 发送消息
    PDU* pdu = mkPDU(msg.size() + 1);
    pdu->uiMsgType = ENUM_MSG_TYPE_RPIVATECHAR_REQUEST;

    QString name = DiskClient::getInstance().getName();
    QString chatUser = ui->label_name->text().split("-")[0];
    //qDebug() << "chatUser:" << chatUser;
    memcpy(pdu->caData,chatUser.toStdString().c_str(),64);
    memcpy(pdu->caData+64,name.toStdString().c_str(),64);
    memcpy(pdu->caMsg,msg.toStdString().c_str(),msg.size());
    DiskClient::getInstance().SendMessage(pdu);
    free(pdu);
    pdu = NULL;

    // 显示消息
    ui->textEdit_showMSg->append("我：" + filterNonPrintable(msg));

    // 清空输入框
    ui->lineEdit_Msg->clear();
}

