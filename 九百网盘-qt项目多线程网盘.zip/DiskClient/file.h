#ifndef FILE_H
#define FILE_H

#include <QWidget>
#include "diskclient.h"
#include <QProgressBar>
#include <QStandardPaths>
#include <QVBoxLayout>
namespace Ui {
class File;
}

class File : public QWidget
{
    Q_OBJECT

public:
    explicit File(QWidget *parent = nullptr);
    static File& getInstance();
    ~File();
    void FlushFiles(PDU* pdu);
    void PressFlushFiles();
    QString filterNonPrintable(const QString &input);
    void startDownload(PDU* pdu);
signals:
    void mkdirRequested(const QString &currentPath, const QString &dirName);
    void flushFilesRequested(const QString &currentPath);
    void uploadRequested(const QString &currentPath, const QString &fileName,qint64 fileSize, const QString &userName);
    void UploadFileBeginning(QByteArray caData, qint64 fileSize);
    void deleteRequested(const QString &currentPath);
    void renameRequested(const QString &currentPath,const QString &OldName,const QString &newName);
    void downloadRequested(const QString &DownPath,const QString &currentPath,const QString &fileName);
    void downstart(qint64 fileSize);
public slots:
    void startUpload();
    void IntoDir();
    void startReceivingFile(QByteArray caData);
private slots:
    void on_btnmkdir_clicked();
    void on_btnupload_clicked();
    void on_btnFlushFiles_clicked();

    void on_btnBack_clicked();

    void on_btnDelete_clicked();

    void on_btnRename_clicked();

    void on_btnDownload_clicked();

private:
    Ui::File *ui;
    QString m_currentPath;
    QString m_rootPath;
    QString FilePath;
    QThread* thread;
    class FileThread* fileThread; // 前向声明
private:
    QProgressBar* m_pProgressBar;
    QDialog *m_pDialog;
    QVBoxLayout *m_pVLayout;
    qint64 FileMaxSize;
};

#endif // FILE_H
