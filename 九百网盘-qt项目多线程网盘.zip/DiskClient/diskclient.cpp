#include "diskclient.h"
#include "ui_diskclient.h"
#include <QDir>
#include <QMessageBox>

DiskClient::DiskClient(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::DiskClient)
{
    ui->setupUi(this);
    m_socket = new QTcpSocket(this);
    ip = "127.0.0.1";
    port = 9999;
    m_download = false; //是否在下载文件状态
    connect(m_socket, &QTcpSocket::connected, this, &DiskClient::onConnected); //连接成功
    connect(m_socket, &QTcpSocket::disconnected, this, &DiskClient::onDisconnected);//断开连接
    connect(m_socket, &QTcpSocket::readyRead, this, &DiskClient::onReadyRead);//有数据可读
    // 连接 socket 错误信号
    connect(m_socket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::errorOccurred),
            this, &DiskClient::onError);
    connect(this,&DiskClient::HandlePDU,this,&DiskClient::DealPDUs);//处理PDU，解析Type
    // Load config
    loadConfig();
    connectToServer(ip,port);//连接服务器
}

DiskClient &DiskClient::getInstance()//单例模式
{
    static DiskClient instance;
    return instance;
}

DiskClient::~DiskClient()//析构函数
{
    logout(); // Send exit message and disconnect
    if(m_socket)
    {
        m_socket->close();
        m_socket->deleteLater();
    }
    delete ui;
}

QTcpSocket *DiskClient::getSocket()//获取socket
{
    return m_socket;
}

void DiskClient::connectToServer(const QString &ip, quint16 port)
{
    qDebug() << "Connecting to server...";
    m_socket->connectToHost(ip, port);
}

void DiskClient::SendMessage(PDU* pdu)//发送消息
{
    if(m_socket->state() == QAbstractSocket::ConnectedState)
    {
        //qDebug() << "Sending message...";
        //qDebug()<<"发送大小:"<<pdu->uiPDULen;
        m_socket->write((char*)pdu,pdu->uiPDULen);//发送数据
        m_socket->flush();
    }
    else
    {
        qDebug() << "Not connected to server.";
    }
}

void DiskClient::loadConfig()//加载配置文件
{
    // Disable buttons before connecting to server
    ui->btnLogin->setEnabled(false);
    ui->btnRegister->setEnabled(false);
    ui->btnExit->setEnabled(false);
    //读取config文件
    QFile file(":/client.config");
    file.open(QIODevice::ReadOnly);
    if (!file.isOpen())
    {
        qDebug() << "Failed to open config file.";
        return;
    }
    QTextStream in(&file);
    ip = in.readLine();
    port = in.readLine().toUShort();
    configPath = in.readLine();
    m_SharePath = in.readLine();
    file.close();
}

void DiskClient::onConnected()//连接成功
{
    qDebug() << "Connected to server.";
    ui->btnLogin->setEnabled(true);
    ui->btnRegister->setEnabled(true);
    ui->btnExit->setEnabled(true);
    ShowAutoCloseMessageBox("连接服务器","连接成功",500);
}

void DiskClient::logout()//退出登录
{
    if(m_socket->state() == QAbstractSocket::ConnectedState)
    {
        // Create a PDU for exit
        PDU* pdu = mkPDU(0);
        pdu->uiMsgType = ENUM_MSG_TYPE_USER_EXIT;
        memcpy(pdu->caData, m_name.toStdString().c_str(), 64);
        memcpy(pdu->caData + 64, m_pwd.toStdString().c_str(), 64);

        // Send the exit message
        SendMessage(pdu);
        m_socket->flush(); // Ensure data is sent

        // Optionally wait for acknowledgment
        if(!m_socket->waitForBytesWritten(2000)) // Wait up to 3 seconds
        {
            qDebug() << "Failed to send exit message in time.";
        }

        free(pdu);
    }

}

void DiskClient::socketSendData(PDU *pdu)//发送数据
{
    qint64 size = m_socket->write((char*)pdu,pdu->uiPDULen);
    m_socket->flush();
    qDebug()<<"发送数据大小:"<<size;
}

void DiskClient::onDisconnected()//断开连接，暂时没有用到
{
    qDebug() << "Disconnected from server.";
}

void DiskClient::onReadyRead()//读数据
{
    // 将新接收的数据追加到缓冲区
    m_buffer.append(m_socket->readAll());

    // 循环解析缓冲区中的 PDU
    while (true) {
        // 检查缓冲区是否至少有 sizeof(uint) 字节来读取 uiPDULen
        if (static_cast<size_t>(m_buffer.size()) < sizeof(uint)) {
            // 数据不足，等待更多数据到达
            break;
        }

        // 从缓冲区读取 uiPDULen
        uint uiPDULen;
        memcpy(&uiPDULen, m_buffer.constData(), sizeof(uint));

        // 检查 uiPDULen 是否合理
        if (uiPDULen < sizeof(PDU)) {
            qDebug() << "接收到的 PDU 长度无效：" << uiPDULen;
            // 这里可以选择断开连接或清空缓冲区
            // this->disconnectFromHost();
            m_buffer.clear();
            return;
        }

        // 检查缓冲区中是否有完整的 PDU 数据
        if (static_cast<size_t>(m_buffer.size()) < uiPDULen) {
            // 数据不足，等待更多数据到达
            break;
        }

        // 提取完整的 PDU 数据
        QByteArray pduData = m_buffer.mid(0, uiPDULen);
        m_buffer.remove(0, uiPDULen); // 移除已处理的数据

        // 解析 PDU 结构
        PDU* pdu = (PDU*)pduData.constData();

        // 处理不同类型的 PDU
        if (m_download > 0) {
            qDebug() << "开始接收文件";

            // 确保 uiMsgLen 不超过 caMsg 的实际大小
            if (pdu->uiMsgLen > 0 && pdu->uiMsgLen <= (uiPDULen - sizeof(PDU))) {
                QByteArray fileData = QByteArray(pdu->caMsg, pdu->uiMsgLen);
                qDebug() << "实际文件数据大小：" << fileData.size();
                qDebug() <<"m_download的标识值："<< m_download;
                // 将副本传递给 file 处理
                if(m_download == 1)
                {
                    QMetaObject::invokeMethod(Operator::getInstance().getFileSystem(), "startReceivingFile",
                                              Qt::QueuedConnection,
                                              Q_ARG(QByteArray, fileData));
                }else if(m_download == 2)
                {
                    QMetaObject::invokeMethod(Operator::getInstance().getShareFiles(), "startReceivingFile",
                                              Qt::QueuedConnection,
                                              Q_ARG(QByteArray, fileData));
                }

            } else {
                qDebug() << "文件数据长度不正确或超出范围：" << pdu->uiMsgLen;
            }
        } else {
            emit HandlePDU(pdu);
        }
        // 注意：由于 pduData 是 QByteArray 的一部分，pdu 的内存由 QByteArray 管理
        // 无需手动释放 pdu
    }
}

void DiskClient::onError(QAbstractSocket::SocketError socketError)
{
    qDebug() << "Error:" << socketError;
}

void DiskClient::DealPDUs(PDU *pdu)//处理PDU（不是文件部分）
{
    switch (pdu->uiMsgType) {
        case ENUM_MSG_TYPE_REGIST_RESPOND://注册响应
        {
            qDebug() << "Register response: " << pdu->caData;
            ShowAutoCloseMessageBox("注册",QString(pdu->caData),500);
            char name[64] = {'\0'};
            memcpy(name,pdu->caData+64,64);
            if(QString(pdu->caData).trimmed() == "注册成功")
            {
                qDebug()<<"创建用户目录";
                QDir dir;
                QString path = configPath + "/" + QString(name);
                if(!dir.exists(path))
                {
                    if(dir.mkpath(path))
                    {
                        qDebug() << "Create user directory successfully.";
                    }
                    else
                    {
                        qDebug() << "Failed to create user directory.";
                    }
                }
                m_RootPath = path;//设置根目录
                m_CurrentPath = path;//设置当前目录
            }
        }
        break;
        case ENUM_MSG_TYPE_LOGIN_RESPOND://登录响应
        {
            qDebug() << "Login response: " << pdu->caData;
            if(QString(pdu->caData).trimmed() == "登录成功")
            {
                m_name = ui->name->text();//获取用户名
                m_pwd = ui->pwd->text();//获取密码

                char path[64] = {'\0'};//用户目录
                memcpy(path,pdu->caData+64,64);//获取用户目录
                m_RootPath = QString(path);//设置根目录
                m_CurrentPath = QString(path);//设置当前目录
                this->hide();//隐藏登录界面
                Operator::getInstance().show();//显示主界面
                Operator::getInstance().getFriends()->SetName(m_name);//设置用户名
                Operator::getInstance().getFriends()->PressedFlushFriend();//刷新好友
                //Operator::getInstance().getFileSystem()->PressFlushFiles();//刷新文件//会崩溃，不知道原因
            }
            ShowAutoCloseMessageBox("登录",QString(pdu->caData),500);
        }
        break;
        case ENUM_MSG_TYPE_ONLINE_FRIENDS_RESPOND://在线好友响应
        {
            QStringList friendsList;
            int numFriends = pdu->uiMsgLen / 64;
            qDebug() << "Number of online friends: " << numFriends;

            // 验证 uiMsgLen 是否是 64 的倍数
            if (pdu->uiMsgLen % 64 != 0) {
                qWarning() << "PDU message length is not a multiple of 64.";
                break;
            }

            for(int i = 0; i < numFriends; i++)
            {
                // 确保每个好友名是以 '\0' 结尾的 C 字符串
                QString friendName = QString::fromUtf8(pdu->caMsg + i*64);
                //qDebug() << friendName;
                if(friendName.compare(this->m_name)==0)
                {
                    continue;
                }
                friendsList.append(friendName);
            }
            OnlineUsers::getInstance().showOnlineFriends(friendsList);
        }
        break;
        case ENUM_MSG_TYPE_ADD_FRIENDS_RESPOND://添加好友回应
        {
            qDebug() << "Add friend response: " << pdu->caData;
            ShowAutoCloseMessageBox("添加好友",QString(pdu->caData),1000);
        }
        break;
        case ENUM_MSG_TYPE_ADD_FRIENDS_REQUEST://添加好友请求
        {
            qDebug() << "Add friend request: " << pdu->caData;
            QString friendName = QString::fromUtf8(pdu->caData);
            int ret = QMessageBox::question(this, "添加好友", friendName + " 请求添加您为好友，是否同意？",
                                            QMessageBox::Yes | QMessageBox::No);
            if(ret == QMessageBox::Yes)
            {
                PDU* pdu = mkPDU(0);
                pdu->uiMsgType = ENUM_MSG_TYPE_ADD_FRIENDS_AGREE_RESPOND;
                memcpy(pdu->caData, friendName.toStdString().c_str(), 64);//发送对方的名字
                memcpy(pdu->caData+64,m_name.toStdString().c_str(),64);//发送自己的名字
                SendMessage(pdu);
                free(pdu);
            }
            else
            {
                PDU* pdu = mkPDU(0);
                pdu->uiMsgType = ENUM_MSG_TYPE_ADD_FRIENDS_REJUCT_RESPOND;
                memcpy(pdu->caData, friendName.toStdString().c_str(), 64);
                memcpy(pdu->caData+64,m_name.toStdString().c_str(),64);//发送自己的名字
                SendMessage(pdu);
                free(pdu);
            }

        }
        break;
        case ENUM_MSG_TYPE_ADD_FRIENDS_AGREE_RESPOND://添加好友同意回应
        {
            qDebug() << "Add friend response: " << pdu->caData;
            ShowAutoCloseMessageBox("同意添加好友",QString(pdu->caData+64)+"同意添加好友",2000);
        }
        break;
        case ENUM_MSG_TYPE_ADD_FRIENDS_REJUCT_RESPOND://添加好友拒绝回应
        {
            qDebug() << "Add friend response: " << pdu->caData;
            ShowAutoCloseMessageBox("添加好友",QString(pdu->caData+64)+"同意添加好友",2000);
        }
        break;
        case ENUM_MSG_TYPE_SEARCH_USERS_RESPOND://查找用户回应
        {
            qDebug() << "Search friend response: " << pdu->caData;
            QStringList friendsList;
            int numFriends = pdu->uiMsgLen / 64;
            qDebug() << "Number of online friends: " << numFriends;
            for(int i = 0; i < numFriends; i++)
            {
                // 确保每个好友名是以 '\0' 结尾的 C 字符串
                QString friendName = QString::fromUtf8(pdu->caMsg + i*64);
                //qDebug() << friendName;
                friendsList.append(friendName);
            }

            //OnlineUsers::getInstance().showOnlineFriends(friendsList);
            Operator::getInstance().getFriends()->showSearchUsers(friendsList);
            Operator::getInstance().getFriends()->PressedFlushFriend();
        }
        break;
        case ENUM_MSG_TYPE_FLUSH_FRIENDS_RESPOND://刷新好友回应
        {
            QStringList friendsList;
            int numFriends = pdu->uiMsgLen / 64;
            qDebug() << "Number of online friends: " << numFriends;
            for(int i = 0; i < numFriends; i++)
            {
                // 确保每个好友名是以 '\0' 结尾的 C 字符串
                QString friendName = QString::fromUtf8(pdu->caMsg + i*64);
                //qDebug() << friendName;
                friendsList.append(friendName);
            }

            Operator::getInstance().getFriends()->FlushFriends(friendsList);
        }
        break;
        case ENUM_MSG_TYPE_DELETE_FRIENDS_RESPOND://删除好友回应
        {
            qDebug() << "Delete friend response: " << pdu->caData;
            ShowAutoCloseMessageBox("删除好友",QString(pdu->caData),2000);
            Operator::getInstance().getFriends()->PressedFlushFriend();
        }
        break;
        case ENUM_MSG_TYPE_SEND_MESSAGE_REQUEST://发送消息请求
        {
            qDebug() << "Chat request from : " << pdu->caData;
            Operator::getInstance().getFriends()->showMsgPDU(pdu);
        }
        break;
        case ENUM_MSG_TYPE_RPIVATECHAR_REQUEST://私聊请求
        {
            qDebug()<<"私聊请求";
            PrivateChat::getIntance().showPrivateWindow(pdu);
        }
        break;
        case ENUM_MSG_TYPE_MKDIR_RESPOND://创建文件夹响应
        {
            qDebug() << "Mkdir response: " << pdu->caData;
            ShowAutoCloseMessageBox("创建文件夹",QString(pdu->caData),500);
            //File::getInstance().FlushFiles(pdu);
            Operator::getInstance().getFileSystem()->FlushFiles(pdu);
        }
        break;
        case ENUM_MSG_TYPE_LS_RESPOND://列举文件回应
        {
            Operator::getInstance().getFileSystem()->FlushFiles(pdu);
        }
        break;
        case ENUM_MSG_TYPE_UPLOAD_RESPOND://上传文件响应
        {
            qDebug() << "Upload response: " << pdu->caData;
            //ShowAutoCloseMessageBox("上传文件",QString(pdu->caData),500); //概率崩溃
            Operator::getInstance().getFileSystem()->startUpload();
        }
        break;
        case ENUM_MSG_TYPE_UPLOAD_FINISHED://上传文件完成
        {
            qDebug() << "Upload finished: " << pdu->caData;
            //ShowAutoCloseMessageBox("上传文件",QString(pdu->caData),500);
            //QMessageBox::information(this, "上传文件", QString(pdu->caData), QMessageBox::Ok);//会阻塞导致刷新无法生效
            Operator::getInstance().getFileSystem()->PressFlushFiles();
            Operator::getInstance().getShareFiles()->PressFlushFiles();
        }
        break;
        case ENUM_MSG_TYPE_DELETE_FILE_RESPOND:
        {
            qDebug() << "Delete file response: " << pdu->caData;
            //ShowAutoCloseMessageBox("删除文件",QString(pdu->caData),500);
            Operator::getInstance().getFileSystem()->PressFlushFiles();
        }
        break;
        case ENUM_MSG_TYPE_RENAME_FILE_RESPOND:
        {
            qDebug() << "Rename file response: " << pdu->caData;
            //ShowAutoCloseMessageBox("删除文件",QString(pdu->caData),500);
            Operator::getInstance().getFileSystem()->PressFlushFiles();
        }
        break;
        case ENUM_MSG_TYPE_LS_SHAREAREA_RESPOND://列举共享文件区
        {
            Operator::getInstance().getShareFiles()->FlushShareFiles(pdu);
        }
        break;
        case ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND://下载文件响应
        {
            qDebug() << "Download response: " << pdu->caData;
            if(QString(pdu->caData).trimmed() == DOWNLOAD_FILE_START)
            {
                if(QString(pdu->caData+64).trimmed() == DOWNLOAD_FILE_SHARE)
                {
                    Operator::getInstance().getShareFiles()->startDownload(pdu);//开始下载
                }
                else
                {
                    Operator::getInstance().getFileSystem()->startDownload(pdu);//开始下载
                }
                return;
            }
            else
            {
                ShowAutoCloseMessageBox("下载文件",QString(pdu->caData),500);
                m_download = false;
            }
        }
        break;
    // 处理其他消息类型...
    default:
        break;
    }
}

void DiskClient::on_btnLogin_clicked()//登录
{
    QString username = ui->name->text();
    QString password = ui->pwd->text();

    if(username.isEmpty() || password.isEmpty())
    {
        ShowAutoCloseMessageBox("登录","用户名或者密码不能为空",500);
        return;
    }
    // Create a PDU
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUM_MSG_TYPE_LOGIN_REQUEST;
    memcpy(pdu->caData,username.toStdString().c_str(),64);
    memcpy(pdu->caData+64,password.toStdString().c_str(),64);

    SendMessage(pdu);//发送数据

    free(pdu);
    pdu = nullptr;

}

void DiskClient::on_btnRegister_clicked()//注册
{
    QString username = ui->name->text();
    QString password = ui->pwd->text();

    if(username.isEmpty() || password.isEmpty())
    {
        ShowAutoCloseMessageBox("注册","用户名或者密码不能为空",1000);
        return;
    }
    // Create a PDU
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUM_MSG_TYPE_REGIST_REQUEST;
    memcpy(pdu->caData,username.toStdString().c_str(),64);
    memcpy(pdu->caData+64,password.toStdString().c_str(),64);

    SendMessage(pdu);//发送数据

    free(pdu);
    pdu = nullptr;
}

void DiskClient::ShowAutoCloseMessageBox(const QString &title, const QString &text, int timeout)//自动关闭消息框
{
    QMessageBox *msgBox = new QMessageBox(this);
    msgBox->setIcon(QMessageBox::Information);
    msgBox->setWindowTitle(title);
    msgBox->setText(text);
    msgBox->setStandardButtons(QMessageBox::Ok);
    msgBox->setAttribute(Qt::WA_DeleteOnClose); // 确保对话框关闭后被删除

    // 启动定时器，在 timeout 毫秒后关闭消息框
    QTimer::singleShot(timeout, msgBox, &QMessageBox::accept);

    // 显示消息框
    msgBox->show();
}

QString DiskClient::getName() const
{
    return m_name;
}

void DiskClient::setName(const QString &name)
{
    m_name = name;
}

QString DiskClient::getPwd() const
{
    return m_pwd;
}

void DiskClient::setPwd(const QString &pwd)
{
    m_pwd = pwd;
}

QString DiskClient::getRootPath() const
{
    return m_RootPath;
}

void DiskClient::setRootPath(const QString &rootpath)
{
    m_RootPath = rootpath;
}

QString DiskClient::getCurrentPath() const
{
    return m_CurrentPath;
}

void DiskClient::setCurrentPath(const QString &currentPath)
{
    m_CurrentPath = currentPath;
}

QString DiskClient::getSharePath() const
{
    return m_SharePath;
}

void DiskClient::setSharePath(const QString &sharePath)
{
    m_SharePath = sharePath;
}

void DiskClient::DownloadFile(int isDownload)//设置下载文件标签
{
    m_download = isDownload;
}
