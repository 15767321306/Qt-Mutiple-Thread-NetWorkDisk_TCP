#include "filethread.h"
#include <QDebug>
#include <qfileinfo.h>
#include "operator.h"
#include "memory.h"
#include "diskclient.h"
FileThread::FileThread(QObject *parent)
    : QObject(parent)
{
    m_transFile = new TransFile();
}

void FileThread::handleMkdirRequest(const QString &currentPath, const QString &dirName)
{
    //qDebug() << "FileThread: 处理新建文件夹请求";
    PDU* pdu = mkPDU(currentPath.size() + 1);
    pdu->uiMsgType = ENUM_MSG_TYPE_MKDIR_REQUEST;
    memcpy(pdu->caData, dirName.toStdString().c_str(),64);
    memcpy(pdu->caMsg, currentPath.toStdString().c_str(), currentPath.size() + 1);

    //DiskClient::getInstance().SendMessage(pdu);
    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));
    free(pdu);
    pdu = NULL;
}

void FileThread::handleFlushFilesRequest(const QString &currentPath)
{
   // qDebug() << "FileThread: 处理刷新文件列表请求";
    PDU* pdu = mkPDU(currentPath.size() + 1);
    pdu->uiMsgType = ENUM_MSG_TYPE_LS_REQUEST;
    memcpy(pdu->caMsg, currentPath.toStdString().c_str(), currentPath.size() + 1);


    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));

    free(pdu);
    pdu = NULL;
}

void FileThread::handleUploadRequest(const QString &currentPath, const QString &filePath,qint64 fileSize,const QString &userName)
{
    //qDebug() << "FileThread: 处理上传文件请求";
    PDU* pdu = mkPDU(currentPath.size() + 1);
    // 使用 QFileInfo 提取文件名
    QFileInfo fileInfo(filePath);
    QString fileName = fileInfo.fileName(); // 例如 "Makefile"

    pdu->uiMsgType = ENUM_MSG_TYPE_UPLOAD_REQUEST;
    memcpy(pdu->caMsg, currentPath.toStdString().c_str(), currentPath.size() + 1);
    snprintf(pdu->caData, sizeof(pdu->caData), "%s %lld", fileName.toStdString().c_str(), fileSize);
    memcpy(pdu->caData + 64,userName.toStdString().c_str(),64);

    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));

    free(pdu);
    pdu = NULL;
}

void FileThread::UploadFileBeginning(QByteArray caData, qint64 fileSize) {

    PDU* pdu = mkPDU(fileSize);
    // 确保 buf 的大小不会超过 pdu->caMsg 的大小
    if (fileSize <= pdu->uiMsgLen) {
        memcpy(pdu->caMsg, caData.data(), fileSize);
    } else {
        qDebug() << "数据大小超出限制!";
        return; // 或者其他错误处理
    }
    // 发送消息
    QMetaObject::invokeMethod(&DiskClient::getInstance(), "socketSendData", Qt::QueuedConnection,
                                  Q_ARG(PDU*, pdu));

}

void FileThread::handleDeleteRequest(const QString &currentPath)
{
    if(currentPath.isEmpty())
    {
        return;
    }
    PDU* pdu = mkPDU(currentPath.size());
    pdu->uiMsgType = ENUM_MSG_TYPE_DELETE_FILE_REQUEST;
    memcpy(pdu->caMsg, currentPath.toStdString().c_str(), currentPath.size() + 1);

    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));
}

void FileThread::handleRenameRequest(const QString &currentPath,const QString &OldName, const QString &newName)
{
    if(currentPath.isEmpty())
    {
        return;
    }
    PDU* pdu = mkPDU(currentPath.size() + 1);
    pdu->uiMsgType = ENUM_MSG_TYPE_RENAME_FILE_REQUEST;
    memcpy(pdu->caMsg, currentPath.toStdString().c_str(), currentPath.size() + 1);
    memcpy(pdu->caData, OldName.toStdString().c_str(),64);
    memcpy(pdu->caData+64,newName.toStdString().c_str(),64);

    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));
}

void FileThread::handleDownloadRequest(const QString &DownloadPath,const QString &currentPath, const QString &fileName)
{
    if(currentPath.isEmpty())
    {
        return;
    }
    PDU* pdu = mkPDU(currentPath.size() + 1);
    m_transFile->file.setFileName(DownloadPath);
    pdu->uiMsgType = ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST;
    memcpy(pdu->caData, fileName.toStdString().c_str(),64);
    memcpy(pdu->caMsg,currentPath.toStdString().c_str(),currentPath.size() + 1);

    QMetaObject::invokeMethod(&DiskClient::getInstance(), "SendMessage", Qt::QueuedConnection,
                              Q_ARG(PDU*, pdu));
    qDebug()<<"发送下载请求";
}

void FileThread::downstart(qint64 fileSize)
{
    qDebug()<<"下载回应开始";

    if(m_transFile->file.open(QIODevice::WriteOnly))
    {
        m_transFile->bTransform = true;
        m_transFile->iTotalSize = fileSize;
        m_transFile->iReceivedSize = 0;

        QMetaObject::invokeMethod(&DiskClient::getInstance(), "DownloadFile", Qt::QueuedConnection,
                                  Q_ARG(int, 1));
    }
    else
    {
        qDebug()<<"打开文件失败";
    }
}

void FileThread::DownloadingFile(QByteArray caData)
{
    if(m_transFile->bTransform)
    {
        qDebug()<<"下载开始";
        // 将 QByteArray 的数据写入文件
        if (m_transFile->file.write(caData) == -1) {
            qDebug() << "写入文件失败，错误:" << m_transFile->file.errorString();
            return; // 写入失败，直接返回
        }

        // 更新已接收大小

        m_transFile->iReceivedSize += caData.size();
        qDebug() << "已接收大小:" << m_transFile->iReceivedSize;

        // 调试信息
        qDebug() << "预期接收总大小:" << m_transFile->iTotalSize;

        //emit progressUpdate(m_transFile->iReceivedSize,m_transFile->iTotalSize);
        if(m_transFile->iReceivedSize == m_transFile->iTotalSize) {
            m_transFile->file.close();
            m_transFile->bTransform = false;
            qDebug() << "文件接收完毕";
            QMetaObject::invokeMethod(&DiskClient::getInstance(), "DownloadFile", Qt::QueuedConnection,Q_ARG(int, 0));

        }else if(m_transFile->iReceivedSize > m_transFile->iTotalSize) {
            qDebug() << "接收大小超过预期大小";
            qDebug() << "接收大小:" << m_transFile->iReceivedSize;
            qDebug() << "预期大小:" << m_transFile->iTotalSize;
            QMetaObject::invokeMethod(&DiskClient::getInstance(), "DownloadFile", Qt::QueuedConnection,Q_ARG(int, 0));
        }
    }
}



