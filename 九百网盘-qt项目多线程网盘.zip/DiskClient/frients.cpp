#include "frients.h"
#include "ui_frients.h"

#include <QDir>
#include <QInputDialog>

Frients::Frients(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Frients)
{
    ui->setupUi(this);
    this->setLayout(ui->verticalLayout_3);

}

Frients &Frients::getInstance()
{
    static Frients instance;
    return instance;
}

Frients::~Frients()
{
    delete ui;
}

void Frients::SetName(QString name)
{
    ui->label_username->setText(name);
}

void Frients::showSearchUsers(QStringList users)
{
    QDialog *dialog = new QDialog(this);

    QVBoxLayout *layout = new QVBoxLayout(dialog);
    dialog->setLayout(layout);

    QLabel *label = new QLabel("搜索结果", dialog);
    layout->addWidget(label);

    QListWidget *listWidget = new QListWidget(dialog);

    for (const QString &userName : users)
    {
        listWidget->addItem(userName);
    }

    layout->addWidget(listWidget);

    QPushButton *button = new QPushButton("添加好友", dialog);
    layout->addWidget(button);

    connect(button, &QPushButton::clicked, [=]() {
        QListWidgetItem *item = listWidget->currentItem();
        if (item == NULL) {
            qDebug() << "No friend selected.";
            return;
        }
        QString friendName = item->text();
        qDebug() << "Selected friend: " << friendName;
        PDU* pdu = mkPDU(0);
        pdu->uiMsgType = ENUM_MSG_TYPE_ADD_FRIENDS_REQUEST;
        QString name = DiskClient::getInstance().getName();
        memcpy(pdu->caData,name.toStdString().c_str(),64);

        memcpy(pdu->caData+64,friendName.toStdString().c_str(),64);
        DiskClient::getInstance().SendMessage(pdu);
        free(pdu);
        pdu = NULL;
    });

    dialog->show();
}

void Frients::FlushFriends(QStringList friendslist)
{
    // 清空现有项
    ui->listWidgetFriends->clear();

    // 添加在线好友数量信息
    ui->listWidgetFriends->addItem("总共：" + QString::number(friendslist.size()/2) + " 在线用户");

    // 打印每个用户的详细信息
    for (const QString &friendInfo : friendslist)
    {
        // 分割好友信息为名称和在线状态
        QStringList infoParts = friendInfo.split('|');
        if (infoParts.size() == 2) // 确保有两个部分
        {
            QString friendName = infoParts[0];
            QString onlineStatus = infoParts[1];

            // 根据在线状态添加信息
            if (onlineStatus == "1") // 根据实际在线状态字符串进行比较
            {
                ui->listWidgetFriends->addItem(friendName + "\r\t (在线)");
            }
            else
            {
                ui->listWidgetFriends->addItem(friendName + "\r\t (不在线)");
            }

            qDebug() << "好友名：" << friendName << " 在线状态：" << onlineStatus;
        }
    }

    // 确保更新
    ui->listWidgetFriends->update();
}

void Frients::PressedFlushFriend()
{
    on_btnFlushFriends_clicked();
}

// 辅助函数：过滤掉不需要的字符
QString filterNonPrintable(const QString &input) {
    QString filtered;
    for (QChar c : input) {
        // 保留 ASCII >= 32，或者是 '\n' 或 '\t'
        if (c.unicode() >= 32 || c == '\n' || c == '\t') {
            filtered.append(c);
        }
    }
    return filtered;
}

void Frients::WriteMsgIntoTextEdit(const QString msg)
{
    QString name = DiskClient::getInstance().getName();

    QFont fixedFont("Segoe UI", 12); // 使用可靠的字体
    ui->textEdit_showmsg->setFont(fixedFont);

    // 过滤掉不需要的字符
    QString filteredMsg = filterNonPrintable(msg);

    // 创建 QTextCursor 对象
    QTextCursor cursor(ui->textEdit_showmsg->textCursor());

    // 设置文本颜色为绿色
    QTextCharFormat greenFormat;
    greenFormat.setForeground(Qt::green);
    cursor.mergeCharFormat(greenFormat);

    // 插入带颜色的文本
    cursor.insertText(name + ": " + filteredMsg + "\n");

    // 恢复文本颜色为默认（黑色）
    QTextCharFormat blackFormat;
    blackFormat.setForeground(Qt::black);
    cursor.mergeCharFormat(blackFormat);

    // 确保光标位置在文本结尾
    ui->textEdit_showmsg->setTextCursor(cursor);
}

void Frients::showMsgPDU(PDU *pdu)
{
    // 设置 QTextEdit 的字体（如果尚未全局设置）
    QFont fixedFont("Segoe UI", 12); // 使用可靠的字体
    ui->textEdit_showmsg->setFont(fixedFont);

    // 创建 QTextCursor 对象
    QTextCursor cursor(ui->textEdit_showmsg->textCursor());

    // 设置文本颜色为红色
    QTextCharFormat redFormat;
    redFormat.setForeground(Qt::red);
    cursor.mergeCharFormat(redFormat);

    // 确保 pdu->caData 和 pdu->caMsg 的长度和编码正确
    QString senderName = QString::fromLocal8Bit(pdu->caData, 64).trimmed();
    if(senderName.compare(DiskClient::getInstance().getName()) == 0) return;//自己发的消息不显示
    QString message = QString::fromUtf8(pdu->caMsg, pdu->uiMsgLen).trimmed();
    // 检查是否成功转换
    if(senderName.isEmpty() || message.isEmpty()){
        qDebug() << "Failed to convert PDU data to QString. Sender:" << senderName << "Message:" << message;
    }

    QString fullMessage = senderName + ": " + message + "\n";
    fullMessage = filterNonPrintable(fullMessage);
    cursor.insertText(fullMessage, redFormat); // 直接在插入文本时应用格式

    // 恢复文本颜色为默认（黑色）
    QTextCharFormat blackFormat;
    blackFormat.setForeground(Qt::black);
    cursor.mergeCharFormat(blackFormat);

    // 确保光标位置在文本结尾
    ui->textEdit_showmsg->setTextCursor(cursor);
}

void Frients::on_btnShowOnline_clicked()//查找在线
{
    qDebug() << "Show online friends";
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUM_MSG_TYPE_ONLINE_FRIENDS_REQUEST;

    DiskClient::getInstance().SendMessage(pdu);
    OnlineUsers::getInstance().show();
    free(pdu);
    pdu = NULL;
}

void Frients::on_btnFlushFriends_clicked()
{
    qDebug() << "Flush friends";
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUM_MSG_TYPE_FLUSH_FRIENDS_REQUEST;
    QString myName = DiskClient::getInstance().getName();
    memcpy(pdu->caData, myName.toStdString().c_str(), 64);
    DiskClient::getInstance().SendMessage(pdu);
    free(pdu);
    pdu = NULL;
}

void Frients::on_btnPrivateChat_clicked()
{
    //qDebug() << "Private chat";
    QListWidgetItem *item = ui->listWidgetFriends->currentItem();
    if (item == NULL) {
        DiskClient::getInstance().ShowAutoCloseMessageBox("私聊", "还没选择私聊的好友", 1500);
        return;
    }
    QString chatUser = item->text().split(QRegExp("\\s+")).first();


    PrivateChat::getIntance().startChat(chatUser);
}

void Frients::on_btnSendmsg_clicked()//公屏消息
{
    qDebug() << "Send message";
    QString msg = ui->lineEdit_Mymsg->text();
    ui->lineEdit_Mymsg->clear();
    if (msg.isEmpty()) {
        DiskClient::getInstance().ShowAutoCloseMessageBox("发送消息", "消息不能为空", 1500);
        return;
    }
    uint len = msg.length();
    PDU* pdu = mkPDU(len);
    pdu->uiMsgType = ENUM_MSG_TYPE_SEND_MESSAGE_REQUEST;
    QString name = DiskClient::getInstance().getName();
    memcpy(pdu->caData, name.toStdString().c_str(), 64);
    memcpy(pdu->caMsg, msg.toStdString().c_str(), len);
    DiskClient::getInstance().SendMessage(pdu);
    WriteMsgIntoTextEdit(msg);
    free(pdu);
    pdu = NULL;
}

void Frients::on_btnDeleteFriends_clicked()
{
    QListWidgetItem *item = ui->listWidgetFriends->currentItem();
    if (item == NULL) {
        DiskClient::getInstance().ShowAutoCloseMessageBox("删除好友", "还没选择删除的好友", 1500);
        return;
    }
    QString friendName = item->text().split(QRegExp("\\s+")).first();

    qDebug()<<"Delete friends";
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUM_MSG_TYPE_DELETE_FRIENDS_REQUEST;
    QString name = DiskClient::getInstance().getName();
    memcpy(pdu->caData,name.toStdString().c_str(),64);
    memcpy(pdu->caData+64,friendName.toStdString().c_str(),64);
    DiskClient::getInstance().SendMessage(pdu);
    free(pdu);
    pdu = NULL;
}

void Frients::on_btnSearchPerson_clicked()
{
    qDebug() << "Search person";
    bool ok;
    QString text = QInputDialog::getText(this, tr("QInputDialog::getText()"),
                                         tr("User name:"), QLineEdit::Normal,
                                         QDir::home().dirName(), &ok);
    if (ok)  // 只检查是否按下了确定按钮
    {
        if (!text.isEmpty())  // 检查输入是否为空
        {
            PDU* pdu = mkPDU(0);
            pdu->uiMsgType = ENUM_MSG_TYPE_SEARCH_USERS_REQUEST;
            memcpy(pdu->caData, text.toStdString().c_str(), 64);

            DiskClient::getInstance().SendMessage(pdu);
            free(pdu);
            pdu = NULL;
        }
        else
        {
            DiskClient::getInstance().ShowAutoCloseMessageBox("查找在线用户", "查找失败，不能查找空用户", 1500);
        }
    }
}

