#include "diskclient.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    if(QT_VERSION >= QT_VERSION_CHECK(5, 6, 0))
    {
        QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);//支持高分辨率屏幕
    }
    // 注册 PDU* 类型
    qRegisterMetaType<PDU*>("PDU*");
    QApplication a(argc, argv);

    DiskClient &client = DiskClient::getInstance();
    client.show();
    return a.exec();
}
